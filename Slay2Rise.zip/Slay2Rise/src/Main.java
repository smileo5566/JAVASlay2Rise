public class Main {

    public static void main(String[] args) {
        MainFrame mf1 = new MainFrame();
        mf1.setVisible(true);
    }
}
