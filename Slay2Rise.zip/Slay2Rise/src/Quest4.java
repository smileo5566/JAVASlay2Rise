


import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.Timer;


public class Quest4 extends JFrame {
    private Container cp;
    public JFrame map;
    private JPanel jpnC = new JPanel();
    private JPanel jpnN = new JPanel();
    private JPanel jpnTalk = new JPanel();

    //    背景圖

    private JLabel jlbForest = new JLabel();
    //
//    jpnC
    private JLabel jlbAshe = new JLabel();
    private JLabel jlbMonster = new JLabel();
    private ImageIcon iconTa = new ImageIcon("img/Monster/ta.png");
    private ImageIcon iconTa2 = new ImageIcon("img/Monster/ta2.png");


//    jpnTalk
    private JLabel jlbTalk1 = new JLabel("<html><body><p>你看到了一個聖杯，你看到裡面有一個甜甜圈，你要怎麼做呢?</p></body></html>");
    private JLabel jlbChooseA = new JLabel("吃掉甜甜圈");
    private JLabel jlbChooseB = new JLabel("看聖杯底下");
    private JLabel jlbChooseC = new JLabel("拿走聖杯");
    private JLabel jlbChooseD = new JLabel("直接離開");
    private JLabel jlbConfirm = new JLabel("離開");


    public Quest4(JFrame jFrame){
        init(jFrame);
    }
    public void init(JFrame jFrame){
        this.setBounds(150,100,1600,850);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.map = jFrame;
        cp = this.getContentPane();
        cp.setLayout(null);
        cp.add(jpnN);
        cp.add(jpnTalk);
        cp.add(jpnC);
//        jpnTalk
        jpnTalk.setBackground(new Color(0,0,0));
        jpnTalk.setBounds(100,100,1400,650);
        jpnTalk.setLayout(null);
        jpnTalk.add(jlbTalk1);
        jpnTalk.add(jlbChooseA);
        jpnTalk.add(jlbChooseB);
        jpnTalk.add(jlbChooseC);
        jpnTalk.add(jlbChooseD);
        jpnTalk.add(jlbConfirm);
        jlbTalk1.setBounds(300,0,800,325);
        jlbChooseA.setBounds(0,325,700,162);
        jlbChooseB.setBounds(0,488,700,162);
        jlbChooseC.setBounds(700,325,700,162);
        jlbChooseD.setBounds(700,488,700,162);
        jlbConfirm.setBounds(350,488,700,162);
        jlbTalk1.setFont(MyFont.WeiRuan60);
        jlbChooseA.setFont(MyFont.WeiRuan60);
        jlbChooseB.setFont(MyFont.WeiRuan60);
        jlbChooseC.setFont(MyFont.WeiRuan60);
        jlbChooseD.setFont(MyFont.WeiRuan60);
        jlbConfirm.setFont(MyFont.WeiRuan60);
        jlbTalk1.setForeground(Color.white);
        jlbChooseA.setForeground(Color.white);
        jlbChooseB.setForeground(Color.white);
        jlbChooseC.setForeground(Color.white);
        jlbChooseD.setForeground(Color.white);
        jlbConfirm.setForeground(Color.white);
        jlbTalk1.setHorizontalAlignment(SwingConstants.CENTER);
        jlbTalk1.setVerticalAlignment(SwingConstants.CENTER);
        jlbChooseA.setHorizontalAlignment(SwingConstants.CENTER);
        jlbChooseA.setVerticalAlignment(SwingConstants.CENTER);
        jlbChooseB.setHorizontalAlignment(SwingConstants.CENTER);
        jlbChooseB.setVerticalAlignment(SwingConstants.CENTER);
        jlbChooseC.setHorizontalAlignment(SwingConstants.CENTER);
        jlbChooseC.setVerticalAlignment(SwingConstants.CENTER);
        jlbChooseD.setHorizontalAlignment(SwingConstants.CENTER);
        jlbChooseD.setVerticalAlignment(SwingConstants.CENTER);
        jlbConfirm.setHorizontalAlignment(SwingConstants.CENTER);
        jlbConfirm.setVerticalAlignment(SwingConstants.CENTER);
        jlbConfirm.setVisible(false);
        jpnTalk.setVisible(false);

//        jpnC
        jpnC.setBounds(0,0,1600,850);
        jpnC.setLayout(null);
        jpnC.add(jlbAshe);
        jpnC.add(jlbMonster);
        jpnC.add(jlbForest);

//        jpnShop

        jlbAshe.setBounds(250,270,208,222);
        jlbMonster.setBounds(950,220,360,356);
        jlbForest.setBounds(0,0,1600,850);

        jlbForest.setIcon(ImageManager.resize(ImageManager.iconForest, 1600,850,Image.SCALE_SMOOTH));
        jlbAshe.setIcon(ImageManager.resize(ImageManager.iconAshe, 208,222,Image.SCALE_SMOOTH));
        iconTa = ImageManager.resize(iconTa, 360,356,Image.SCALE_SMOOTH);
        iconTa2 = ImageManager.resize(iconTa2, 257,419,Image.SCALE_SMOOTH);

        jlbMonster.setIcon(iconTa);
        jlbMonster.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                jpnTalk.setVisible(true);
                jpnC.setVisible(false);
                jpnN.setVisible(false);
            }
        });
        jlbChooseA.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                jlbTalk1.setText("你的血回復了! hp+30");
                Map.heartInt += 30;
                if (Map.heartInt > 100){
                    Map.heartInt = 100;
                }
                Map.jlbHeartInt.setText(Integer.toString(Map.heartInt));
                jlbChooseA.setVisible(false);
                jlbChooseB.setVisible(false);
                jlbChooseC.setVisible(false);
                jlbChooseD.setVisible(false);
                jlbConfirm.setVisible(true);
            }
        });
        jlbChooseB.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                jlbTalk1.setText("你在杯底發現了一張牌!");
                Card card = new Card("未知的力量",ImageManager.iconCardBuff2);
                Map.VA.add(card);
                Map.cardInt = Map.VA.size();
                Map.jlbCardInt.setText(Integer.toString(Map.cardInt));
                jlbChooseA.setVisible(false);
                jlbChooseB.setVisible(false);
                jlbChooseC.setVisible(false);
                jlbChooseD.setVisible(false);
                jlbConfirm.setVisible(true);
            }
        });
        jlbChooseC.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                jlbTalk1.setText("<html><body><p>你在拿著聖杯準備離開的時候，摔了一跤 -30滴血 獲得100金幣</p></body></html>");
                Map.moneyInt += 100;
                Map.heartInt -= 30;
                Map.jlbMoneyInt.setText(Integer.toString(Map.moneyInt));
                Map.jlbHeartInt.setText(Integer.toString(Map.heartInt));
                jlbChooseA.setVisible(false);
                jlbChooseB.setVisible(false);
                jlbChooseC.setVisible(false);
                jlbChooseD.setVisible(false);
                jlbConfirm.setVisible(true);
            }
        });
        jlbChooseD.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                jlbTalk1.setText("他看起來怪怪的 不要碰他好了");
                jlbChooseA.setVisible(false);
                jlbChooseB.setVisible(false);
                jlbChooseC.setVisible(false);
                jlbChooseD.setVisible(false);
                jlbConfirm.setVisible(true);
            }
        });
        jlbConfirm.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                map.setExtendedState(JFrame.NORMAL);
                Quest4.this.setVisible(false);


            }
        });

    }
}













