import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;

public class Map extends JFrame{
    private Container cp;
    private JPanel jpn1 = new JPanel();
    private  JPanel jpnC = new JPanel();
    private JPanel jpnN = new JPanel();
    private JPanel jpnSetting = new JPanel();
    private  JPanel jpnAbout = new JPanel();
    private  JPanel jpnRename = new JPanel();
    private  JPanel jpnCard = new JPanel();
    private  JPanel jpnCard2 = new JPanel();
    private JScrollPane jsp = new JScrollPane(jpnCard);
    private JScrollBar Bar = jsp.getVerticalScrollBar();
//  Map icon
    private JLabel jlbStage1 = new JLabel();
    private JLabel jlbStage2 = new JLabel();
    private JLabel jlbStage3 = new JLabel();
    private JLabel jlbStage4 = new JLabel();
    private JLabel jlbStage5 = new JLabel();
    private JLabel jlbStage6 = new JLabel();
    private JLabel jlbStage7 = new JLabel();
    private JLabel jlbStage8 = new JLabel();
    private JLabel jlbStage9 = new JLabel();
    private JLabel jlbStage10 = new JLabel();
    private JLabel jlbStage11 = new JLabel();
    private JLabel jlbStage12 = new JLabel();
    private JLabel jlbStage13 = new JLabel();
    private JLabel jlbStage14 = new JLabel();
    private JLabel jlbStage15 = new JLabel();
    private JLabel jlbStageBoss = new JLabel();
    private ImageIcon iconEnemy = new ImageIcon("img/enemy.png");
    private ImageIcon iconEnemyB = new ImageIcon("img/enemyB.png");
    private ImageIcon iconEnemyC = new ImageIcon("img/enemyC.png");
    private ImageIcon iconEnemyR = new ImageIcon("img/enemyR.png");

    private ImageIcon iconShop = new ImageIcon("img/shop.png");
    private ImageIcon iconShopB = new ImageIcon("img/shopB.png");
    private ImageIcon iconShopC = new ImageIcon("img/shopC.png");
    private ImageIcon iconShopR= new ImageIcon("img/shopR.png");

    private ImageIcon iconsEnemy = new ImageIcon("img/sEnemy.png");
    private ImageIcon iconsEnemyB = new ImageIcon("img/sEnemyB.png");
    private ImageIcon iconsEnemyC = new ImageIcon("img/sEnemyC.png");
    private ImageIcon iconsEnemyR = new ImageIcon("img/sEnemyR.png");

    private ImageIcon iconBox = new ImageIcon("img/box.png");
    private ImageIcon iconBoxB = new ImageIcon("img/boxB.png");
    private ImageIcon iconBoxC = new ImageIcon("img/boxC.png");
    private ImageIcon iconBoxR = new ImageIcon("img/boxR.png");

    private ImageIcon iconRest = new ImageIcon("img/rest.png");
    private ImageIcon iconRestB = new ImageIcon("img/restB.png");
    private ImageIcon iconRestC = new ImageIcon("img/restC.png");
    private ImageIcon iconRestR = new ImageIcon("img/restR.png");

    private ImageIcon iconQuest = new ImageIcon("img/quest.png");
    private ImageIcon iconQuestB = new ImageIcon("img/questB.png");
    private ImageIcon iconQuestC = new ImageIcon("img/questC.png");
    private ImageIcon iconQuestR = new ImageIcon("img/questR.png");

    private ImageIcon iconBoss = new ImageIcon("img/boss.png");
    private ImageIcon iconBossR = new ImageIcon("img/bossR.png");
//  Other icon
    private ImageIcon iconPointer = new ImageIcon("img/point.png");
    private JLabel pointerImg = new JLabel();
//  jpnN
    private JLabel moneyImg = new JLabel();
    private JLabel heartImg = new JLabel();
    private JLabel mapImg = new JLabel();
    private JLabel settingImg = new JLabel();
    private JLabel cardImg = new JLabel();


    public static int heartInt = 100;
    public static int moneyInt = 99;
    int nameLength = character.JtfName.getText().length() * 65; //設定職業和暱稱距離
    int roleLength = character.JtfName.getText().length() * 65/2 + 50; //設定職業和暱稱距離


    public static JLabel jlbName = new JLabel(character.JtfName.getText());
    private JLabel jlbRole = new JLabel("神射手");

    public static  JLabel jlbHeartInt = new JLabel(Integer.toString(heartInt));
    public static  JLabel jlbMoneyInt = new JLabel(Integer.toString(moneyInt));

//    jpnSetting
    private JButton jbtAbout = new JButton("About");
    private JButton jbtRename = new JButton("Rename");
    private JButton jbtRetry = new JButton("Retry");
    private JButton jbtClose = new JButton("End");
    private JButton jbtConfirmSetting = new JButton("Confirm");

    private JLabel jlbAbout = new JLabel("<html><body><p>作者 : 謝量 陳鼎超 王哲為</p><br><p>作品名 : Slay 2 Rise</p><br><p>發布日 : 2019/01/10</p><br><p>特別感謝: 林永隆 沒有他就沒有這個專題</p><body></html>");
    private JLabel jlbAboutTitle = new JLabel("About");
    private JButton jbtConfirmAbout = new JButton("Confirm");

    private JTextField jtfRename = new JTextField(" ");
    private JButton jbtConfirmRename = new JButton("Confirm");
    private JLabel jlbRenameTitle = new JLabel("Rename");

//  Other
    private JLabel jlbForest = new JLabel("迷途森林");
    public static int pass1 = 1;

//   牌組VA
    public static int cardInt = 10;
    public static Vector<Card> VA = new Vector(cardInt);

    private Card jlbCard1 = new Card("射擊!",ImageManager.iconCardAtk1);
    private Card jlbCard2 = new Card("射擊!",ImageManager.iconCardAtk1);
    private Card jlbCard3 = new Card("射擊!",ImageManager.iconCardAtk1);
    private Card jlbCard4 = new Card("射擊!",ImageManager.iconCardAtk1);
    private Card jlbCard5 = new Card("射擊!",ImageManager.iconCardAtk1);
    private Card jlbCard6 = new Card("守護!",ImageManager.iconCardShield1);
    private Card jlbCard7 = new Card("守護!",ImageManager.iconCardShield1);
    private Card jlbCard8 = new Card("守護!",ImageManager.iconCardShield1);
    private Card jlbCard9 = new Card("守護!",ImageManager.iconCardShield1);
    private Card jlbCard10 = new Card("光明射擊",ImageManager.iconCardAtk2);

    public static JLabel jlbCardInt = new JLabel(Integer.toString(cardInt));
    private JButton jbtConfirmCard = new JButton("Confirm");
    public static JLabel jlbCardBig = new JLabel();

    public Map(){
        init();
    }
    public void init(){
        this.setBounds(150,100,1600,850);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setDefaultLookAndFeelDecorated(true);
        this.setResizable(false);
        cp = this.getContentPane();
        cp.setLayout(null);
        cp.setBackground(new Color(141,141,130));
        cp.add(jpn1);
        cp.add(jpnN);
        cp.add(jpnC);
        cp.add(jpnSetting);
        cp.add(jpnAbout);
        cp.add(jpnRename);
        cp.add(jsp);
        cp.add(jpnCard2);
        cp.add(jbtConfirmCard);
        jbtConfirmCard.setBounds(1350,370,200,100);
        jbtConfirmCard.setVisible(false);


        jpnC.setBounds(0,0,1600,850);
        jpnC.setBackground(new Color(141,141,130));
        jpnC.setLayout(null);
        jpnC.add(jlbStage1);
        jpnC.add(jlbStage2);
        jpnC.add(jlbStage3);
        jpnC.add(jlbStage4);
        jpnC.add(jlbStage5);
        jpnC.add(jlbStage6);
        jpnC.add(jlbStage7);
        jpnC.add(jlbStage8);
        jpnC.add(jlbStage9);
        jpnC.add(jlbStage10);
        jpnC.add(jlbStage11);
        jpnC.add(jlbStage12);
        jpnC.add(jlbStage13);
        jpnC.add(jlbStage14);
        jpnC.add(jlbStage15);
        jpnC.add(jlbStageBoss);
        jpnC.add(pointerImg);

        jpn1.add(jlbForest);

        jpnN.add(jlbName);
        jpnN.add(jlbRole);
        jpnN.add(heartImg);
        jpnN.add(jlbHeartInt);
        jpnN.add(moneyImg);
        jpnN.add(jlbMoneyInt);
        jpnN.add(jlbCardInt);
        jpnN.add(cardImg);
        jpnN.add(mapImg);
        jpnN.add(settingImg);

        jlbStage1.setBounds(32,232,62,63);
        jlbStage2.setBounds(150,250,26,26);
        jlbStage3.setBounds(247,248,32,30);
        jlbStage4.setBounds(350,245,27,36);
        jlbStage5.setBounds(443,246,40,33);
        jlbStage6.setBounds(547,246,33,34);
        jlbStage7.setBounds(650,245,27,36);
        jlbStage8.setBounds(750,250,26,26);
        jlbStage9.setBounds(844,250,38,27);
        jlbStage10.setBounds(943,246,40,33);
        jlbStage11.setBounds(1047,248,32,30);
        jlbStage12.setBounds(1150,245,27,36);
        jlbStage13.setBounds(1247,246,33,34);
        jlbStage14.setBounds(1350,250,26,26);
        jlbStage15.setBounds(1447,246,33,34);
        jlbStageBoss.setBounds(700,500,188,200);

        pointerImg.setBounds(48,150,30,66);
        pointerImg.setVisible(false);

        jpn1.setBackground(Color.black);
        jpn1.setBounds(0,200,1600,130);
        jlbForest.setBounds(0,0,200,80);
        jlbForest.setFont(MyFont.WeiRuan80);
        jlbForest.setForeground(Color.WHITE);

        jpnN.setBounds(0,0,1600,75);
        jpnN.setBackground(new Color(61,73,78));
        jpnN.setLayout(null);
        jpnN.setVisible(false);
        jlbName.setBounds(10,7,nameLength,65);
        jlbName.setFont(MyFont.Antiqua65);
        jlbName.setForeground(Color.WHITE);
        jlbRole.setBounds(roleLength,23,150,40);
        jlbRole.setFont(MyFont.WeiRuan40);
        heartImg.setBounds(700,20,38,32);
        jlbHeartInt.setBounds(780,10,100,50);
        jlbHeartInt.setFont(MyFont.Antiqua50);
        jlbHeartInt.setForeground(Color.WHITE);
        moneyImg.setBounds(950,17,46,39);
        jlbMoneyInt.setBounds(1030,10,100,50);
        jlbMoneyInt.setFont(MyFont.Antiqua50);
        jlbMoneyInt.setForeground(Color.WHITE);
        cardImg.setBounds(1300,15,49,46);
        jlbCardInt.setBounds(1325,35,30,30);
        jlbCardInt.setFont(MyFont.Antiqua30);
        jlbCardInt.setForeground(new Color(255,128,255));
        mapImg.setBounds(1400,10,53,50);
        settingImg.setBounds(1500,10,53,52);

        jpnSetting.setBackground(new Color(165,191,199));
        jpnSetting.setBounds(600,100,400,550);
        jpnSetting.setLayout(null);
        jpnSetting.add(jbtAbout);
        jpnSetting.add(jbtRename);
        jpnSetting.add(jbtRetry);
        jpnSetting.add(jbtClose);
        jpnSetting.add(jbtConfirmSetting);
        jbtAbout.setBounds(100,50,200,70);
        jbtRename.setBounds(100,150,200,70);
        jbtRetry.setBounds(100,250,200,70);
        jbtClose.setBounds(100,350,200,70);
        jbtConfirmSetting.setBounds(150,470,100,50);
        jbtAbout.setBorder(BorderFactory.createRaisedBevelBorder());
        jbtRename.setBorder(BorderFactory.createRaisedBevelBorder());
        jbtRetry.setBorder(BorderFactory.createRaisedBevelBorder());
        jbtClose.setBorder(BorderFactory.createRaisedBevelBorder());
        jbtConfirmSetting.setBorder(BorderFactory.createRaisedBevelBorder());
        jpnSetting.setVisible(false);

        jpnAbout.setBackground(new Color(165,191,199));
        jpnAbout.setBounds(600,100,400,550);
        jpnAbout.setLayout(null);
        jpnAbout.add(jlbAbout);
        jpnAbout.add(jbtConfirmAbout);
        jpnAbout.add(jlbAboutTitle);
        jlbAboutTitle.setBounds(125,50,150,50);
        jlbAboutTitle.setFont(MyFont.Antiqua50);
        jlbAbout.setBounds(100,100,200,200);
        jbtConfirmAbout.setBounds(150,470,100,50);
        jpnAbout.setVisible(false);

        jpnRename.setBackground(new Color(165,191,199));
        jpnRename.setBounds(600,100,400,550);
        jpnRename.setLayout(null);
        jpnRename.add(jtfRename);
        jpnRename.add(jlbRenameTitle);
        jpnRename.add(jbtConfirmRename);
        jlbRenameTitle.setFont(MyFont.Antiqua50);
        jtfRename.setBounds(100,200,200,50);
        jlbRenameTitle.setBounds(100,50,200,50);
        jbtConfirmRename.setBounds(150,470,100,50);
        jpnRename.setVisible(false);

        VA.addElement(jlbCard1);
        VA.addElement(jlbCard2);
        VA.addElement(jlbCard3);
        VA.addElement(jlbCard4);
        VA.addElement(jlbCard5);
        VA.addElement(jlbCard6);
        VA.addElement(jlbCard7);
        VA.addElement(jlbCard8);
        VA.addElement(jlbCard9);
        VA.addElement(jlbCard10);

        jsp.setBounds(100,120,708,650);
        jsp.setVisible(false);
        Bar.setUnitIncrement(40);

        jpnCard.setBounds(0,0,708,1590);
        jpnCard.setPreferredSize(new Dimension(708,1590));
        jpnCard.setBackground(new Color(165,191,199));
        jpnCard.setVisible(false);
        jpnCard.setLayout(null);

        jpnCard2.setBounds(843,120,485,650);
        jpnCard2.setBackground(new Color(165,191,199));
        jpnCard2.setVisible(false);
        jpnCard2.add(jlbCardBig);
        jlbCardBig.setBounds(0,0,485,650);



//        敵人圖片
        Image imgEnemy = iconEnemy.getImage();
        Image newImgEnemy = imgEnemy.getScaledInstance(26,26, Image.SCALE_SMOOTH);
        iconEnemy = new ImageIcon(newImgEnemy);

        Image imgEnemyB = iconEnemyB.getImage();
        Image newImgEnemyB = imgEnemyB.getScaledInstance(63,63, Image.SCALE_SMOOTH);
        iconEnemyB = new ImageIcon(newImgEnemyB);

        Image imgEnemyC = iconEnemyC.getImage();
        Image newImgEnemyC = imgEnemyC.getScaledInstance(76,79, Image.SCALE_SMOOTH);
        iconEnemyC = new ImageIcon(newImgEnemyC);

        Image imgEnemyR = iconEnemyR.getImage();
        Image newImgEnemyR = imgEnemyR.getScaledInstance(63,63, Image.SCALE_SMOOTH);
        iconEnemyR = new ImageIcon(newImgEnemyR);

//        商人圖片
        Image imgShop = iconShop.getImage();
        Image newImgShop = imgShop.getScaledInstance(32,36, Image.SCALE_SMOOTH);
        iconShop = new ImageIcon(newImgShop);

        Image imgShopB = iconShopB.getImage();
        Image newImgShopB = imgShopB.getScaledInstance(74,70, Image.SCALE_SMOOTH);
        iconShopB = new ImageIcon(newImgShopB);

        Image imgShopC = iconShopC.getImage();
        Image newImgShopC = imgShopC.getScaledInstance(80,77, Image.SCALE_SMOOTH);
        iconShopC = new ImageIcon(newImgShopC);

        Image imgShopR = iconShopR.getImage();
        Image newImgShopR = imgShopR.getScaledInstance(74,70, Image.SCALE_SMOOTH);
        iconShopR = new ImageIcon(newImgShopR);

//        菁英圖片
        Image imgsEnemy = iconsEnemy.getImage();
        Image newImgsEnemy = imgsEnemy.getScaledInstance(40,33, Image.SCALE_SMOOTH);
        iconsEnemy = new ImageIcon(newImgsEnemy);

        Image imgsEnemyB = iconsEnemyB.getImage();
        Image newImgsEnemyB = imgsEnemyB.getScaledInstance(76,59, Image.SCALE_SMOOTH);
        iconsEnemyB = new ImageIcon(newImgsEnemyB);

        Image imgsEnemyC = iconsEnemyC.getImage();
        Image newImgsEnemyC = imgsEnemyC.getScaledInstance(76,79, Image.SCALE_SMOOTH);
        iconsEnemyC = new ImageIcon(newImgsEnemyC);

        Image imgsEnemyR = iconsEnemyR.getImage();
        Image newImgsEnemyR = imgsEnemyR.getScaledInstance(76,59, Image.SCALE_SMOOTH);
        iconsEnemyR = new ImageIcon(newImgsEnemyR);

//        寶相圖片
        Image imgBox = iconBox.getImage();
        Image newImgBox = imgBox.getScaledInstance(38,27, Image.SCALE_SMOOTH);
        iconBox = new ImageIcon(newImgBox);

        Image imgBoxB = iconBoxB.getImage();
        Image newImgBoxB = imgBoxB.getScaledInstance(95,68, Image.SCALE_SMOOTH);
        iconBoxB = new ImageIcon(newImgBoxB);

        Image imgBoxC = iconBoxC.getImage();
        Image newImgBoxC = imgBoxC.getScaledInstance(75,79, Image.SCALE_SMOOTH);
        iconBoxC = new ImageIcon(newImgBoxC);

        Image imgBoxR = iconBoxR.getImage();
        Image newImgBoxR = imgBoxR.getScaledInstance(95,68, Image.SCALE_SMOOTH);
        iconBoxR = new ImageIcon(newImgBoxR);

//        休息圖片
        Image imgRest = iconRest.getImage();
        Image newImgRest = imgRest.getScaledInstance(33,34, Image.SCALE_SMOOTH);
        iconRest = new ImageIcon(newImgRest);

        Image imgRestB = iconRestB.getImage();
        Image newImgRestB = imgRestB.getScaledInstance(77,81, Image.SCALE_SMOOTH);
        iconRestB = new ImageIcon(newImgRestB);

        Image imgRestC = iconRestC.getImage();
        Image newImgRestC = imgRestC.getScaledInstance(80,79, Image.SCALE_SMOOTH);
        iconRestC = new ImageIcon(newImgRestC);

        Image imgRestR = iconRestR.getImage();
        Image newImgRestR = imgRestR.getScaledInstance(77,81, Image.SCALE_SMOOTH);
        iconRestR = new ImageIcon(newImgRestR);


//        問號圖片
        Image imgQuest = iconQuest.getImage();
        Image newImgQuest = imgQuest.getScaledInstance(27,36, Image.SCALE_SMOOTH);
        iconQuest = new ImageIcon(newImgQuest);

        Image imgQuestB = iconQuestB.getImage();
        Image newImgQuestB = imgQuestB.getScaledInstance(59,88, Image.SCALE_SMOOTH);
        iconQuestB = new ImageIcon(newImgQuestB);

        Image imgQuestC = iconQuestC.getImage();
        Image newImgQuestC = imgQuestC.getScaledInstance(79,78, Image.SCALE_SMOOTH);
        iconQuestC = new ImageIcon(newImgQuestC);

        Image imgQuestR = iconQuestR.getImage();
        Image newImgQuestR = imgQuestR.getScaledInstance(59,88, Image.SCALE_SMOOTH);
        iconQuestR = new ImageIcon(newImgQuestR);

//        王圖片
        Image imgBoss = iconBoss.getImage();
        Image newImgBoss = imgBoss.getScaledInstance(188,200, Image.SCALE_DEFAULT);
        iconBoss = new ImageIcon(newImgBoss);


        Image imgBossR = iconBossR.getImage();
        Image newImgBossR = imgBossR.getScaledInstance(188,200, Image.SCALE_SMOOTH);
        iconBossR = new ImageIcon(newImgBossR);

//        其他圖片
        Image imgPointer = iconPointer.getImage();
        Image newImgPointer = imgPointer.getScaledInstance(30,66, Image.SCALE_SMOOTH);
        iconPointer = new ImageIcon(newImgPointer);
        pointerImg.setIcon(iconPointer);
        moneyImg.setIcon(ImageManager.resize(ImageManager.iconMoney, 46,39,Image.SCALE_SMOOTH));
        heartImg.setIcon(ImageManager.resize(ImageManager.iconHeart, 38,32,Image.SCALE_SMOOTH));
        mapImg.setIcon(ImageManager.resize(ImageManager.iconMap, 53,50,Image.SCALE_SMOOTH));
        settingImg.setIcon(ImageManager.resize(ImageManager.iconSetting, 53,52,Image.SCALE_SMOOTH));
        cardImg.setIcon(ImageManager.resize(ImageManager.iconCard, 49,46,Image.SCALE_SMOOTH));


        jlbStage1.setIcon(iconEnemyB);
        jlbStage2.setIcon(iconEnemy);
        jlbStage3.setIcon(iconShop);
        jlbStage4.setIcon(iconQuest);
        jlbStage5.setIcon(iconsEnemy);
        jlbStage6.setIcon(iconRest);
        jlbStage7.setIcon(iconQuest);
        jlbStage8.setIcon(iconEnemy);
        jlbStage9.setIcon(iconBox);
        jlbStage10.setIcon(iconsEnemy);
        jlbStage11.setIcon(iconShop);
        jlbStage12.setIcon(iconQuest);
        jlbStage13.setIcon(iconRest);
        jlbStage14.setIcon(iconEnemy);
        jlbStage15.setIcon(iconRest);
        jlbStageBoss.setIcon(iconBoss);

//        傾聽
        Map.this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(WindowEvent e) {
                Timer timer1 = new Timer();
                super.windowOpened(e);
                timer1.schedule(new TimerTask() {
                      public void run() {
                          jpn1.setVisible(false);
                          jpnN.setVisible(true);
                          pointerImg.setVisible(true);
                        }
                   }, 2500);
            }
        });
        jlbStage1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                if (e.getClickCount() == 1) {
                    if (jlbStage1.getIcon() != iconEnemyC) {
                        Enemy1 en1 = new Enemy1(Map.this);
                        en1.setVisible(true);
                        jlbStage1.setBounds(25,224,76,79);
                        jlbStage1.setIcon(iconEnemyC);
                        jlbStage2.setBounds(132, 232, 62, 63);
                        jlbStage2.setIcon(iconEnemyB);
                        pointerImg.setBounds(148, 150, 30, 66);
                        Map.this.setExtendedState(JFrame.HIDE_ON_CLOSE);
                    }
                }

            }
            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                if (jlbStage1.getIcon() != iconEnemyC) {
                    jlbStage1.setIcon(iconEnemyR);
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                if (jlbStage1.getIcon() != iconEnemyC) {
                    jlbStage1.setIcon(iconEnemyB);
                }

            }
        });

        jlbStage2.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                if (jlbStage1.getIcon() == iconEnemyC) {
                    if (e.getClickCount() == 1) {
                        if (jlbStage2.getIcon() != iconEnemyC) {
                            Enemy2 en2 = new Enemy2(Map.this);
                            en2.setVisible(true);
                            jlbStage2.setBounds(125,224,76,79);
                            jlbStage2.setIcon(iconEnemyC);
                            jlbStage3.setBounds(226,228,74,70);
                            jlbStage3.setIcon(iconShopB);
                            pointerImg.setBounds(248,150,30,66);
                            Map.this.setExtendedState(JFrame.HIDE_ON_CLOSE);
                            pass1 = 2;
                        }
                    }

                }
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                if (jlbStage2.getIcon() != iconEnemyC && jlbStage1.getIcon() == iconEnemyC) {
                    jlbStage2.setIcon(iconEnemyR);
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                if (jlbStage2.getIcon() != iconEnemyC && jlbStage1.getIcon() == iconEnemyC) {
                    jlbStage2.setIcon(iconEnemyB);
                }

            }
        });

        jlbStage3.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                if (jlbStage2.getIcon() == iconEnemyC) {
                    if (e.getClickCount() == 1) {
                        if (jlbStage3.getIcon() != iconShopC) {
                            Shop3 s3 = new Shop3(Map.this);
                            s3.setVisible(true);
                            jlbStage3.setBounds(227,225,80,77);
                            jlbStage3.setIcon(iconShopC);
                            jlbStage4.setBounds(325,234,59,88);
                            jlbStage4.setIcon(iconQuestB);
                            pointerImg.setBounds(348,150,30,66);
                            pass1 = 3;
                            Map.this.setExtendedState(JFrame.HIDE_ON_CLOSE);
                        }
                    }

                }
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                if (jlbStage3.getIcon() != iconShopC && jlbStage2.getIcon() == iconEnemyC) {
                    jlbStage3.setIcon(iconShopR);
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                if (jlbStage3.getIcon() != iconShopC && jlbStage2.getIcon() == iconEnemyC) {
                    jlbStage3.setIcon(iconShopB);
                }

            }
        });

        jlbStage4.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                if (jlbStage3.getIcon() == iconShopC) {
                    if (e.getClickCount() == 1) {
                        if (jlbStage4.getIcon() != iconQuestC) {
                            Quest4 q4 = new Quest4(Map.this);
                            q4.setVisible(true);
                            jlbStage4.setBounds(325,224,76,79);
                            jlbStage4.setIcon(iconQuestC);
                            jlbStage5.setBounds(425,238,76,59);
                            jlbStage5.setIcon(iconsEnemyB);
                            pointerImg.setBounds(448,150,30,66);
                            pass1 = 4;
                            Map.this.setExtendedState(JFrame.HIDE_ON_CLOSE);
                        }
                    }
                }
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                if (jlbStage4.getIcon() != iconQuestC && jlbStage3.getIcon() == iconShopC) {
                    jlbStage4.setIcon(iconQuestR);
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                if (jlbStage4.getIcon() != iconQuestC && jlbStage3.getIcon() == iconShopC) {
                    jlbStage4.setIcon(iconQuestB);
                }

            }
        });
        jlbStage5.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                if (jlbStage4.getIcon() == iconQuestC) {
                    if (e.getClickCount() == 1) {
                        if (jlbStage5.getIcon() != iconsEnemyC) {
                            sEnemy5 sE5 = new sEnemy5(Map.this);
                            sE5.setVisible(true);
                            jlbStage5.setBounds(425, 224, 79, 78);
                            jlbStage5.setIcon(iconsEnemyC);
                            jlbStage6.setBounds(525, 228, 77, 81);
                            jlbStage6.setIcon(iconRestB);
                            pointerImg.setBounds(548, 150, 30, 66);
                            pass1 = 5;
                            Map.this.setExtendedState(JFrame.HIDE_ON_CLOSE);
                        }
                    }
                }
            }



            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                if (jlbStage5.getIcon() != iconsEnemyC && jlbStage4.getIcon() == iconQuestC) {
                    jlbStage5.setIcon(iconsEnemyR);
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                if (jlbStage5.getIcon() != iconsEnemyC && jlbStage4.getIcon() == iconQuestC) {
                    jlbStage5.setIcon(iconsEnemyB);
                }

            }
        });

        jlbStage6.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                if (jlbStage5.getIcon() == iconsEnemyC) {
                    if (e.getClickCount() == 1) {
                        if (jlbStage6.getIcon() != iconRestC) {
                            Rest6 r6 = new Rest6(Map.this);
                            r6.setVisible(true);
                            jlbStage6.setBounds(523,222,80,79);
                            jlbStage6.setIcon(iconRestC);
                            jlbStage7.setBounds(634,219,59,88);
                            jlbStage7.setIcon(iconQuestB);
                            pointerImg.setBounds(648,150,30,66);
                            pass1 = 6;
                            Map.this.setExtendedState(JFrame.HIDE_ON_CLOSE);
                        }
                    }
                }
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
            if (jlbStage6.getIcon() != iconRestC && jlbStage5.getIcon() == iconsEnemyC) {
                jlbStage6.setIcon(iconRestR);
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                if (jlbStage6.getIcon() != iconRestC && jlbStage5.getIcon() == iconsEnemyC) {
                    jlbStage6.setIcon(iconRestB);
                }

            }
        });
        jlbStage7.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
//                if (jlbStage6.getIcon() == iconRestC) {
                    if (e.getClickCount() == 1) {
                        if (jlbStage7.getIcon() != iconQuestC) {
                            Quest7 q7 = new Quest7(Map.this);
                            q7.setVisible(true);
                            jlbStage7.setBounds(625,224,79,78);
                            jlbStage7.setIcon(iconQuestC);
                            jlbStage8.setBounds(732,232,62,63);
                            jlbStage8.setIcon(iconEnemyB);
                            pointerImg.setBounds(748,150,30,66);
                            pass1 = 3;
                            Map.this.setExtendedState(JFrame.HIDE_ON_CLOSE);
                        }
                    }

//            }

            }

            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                if (jlbStage7.getIcon() != iconQuestC && jlbStage6.getIcon() == iconRestC) {
                    jlbStage7.setIcon(iconQuestR);
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                if (jlbStage7.getIcon() != iconQuestC && jlbStage6.getIcon() == iconRestC) {
                    jlbStage7.setIcon(iconQuestB);
                }

            }
        });

        jlbStage8.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);


                if (jlbStage7.getIcon() == iconQuestC) {
                    if (e.getClickCount() == 1) {
                        if (jlbStage8.getIcon() != iconEnemyC) {
                            Enemy8 en8 = new Enemy8(Map.this);
                            en8.setVisible(true);
                            Map.this.setVisible(false);
                            jlbStage8.setBounds(725, 224, 76, 79);
                            jlbStage8.setIcon(iconEnemyC);
                            jlbStage9.setBounds(816, 229, 95, 68);
                            jlbStage9.setIcon(iconBoxB);
                            pointerImg.setBounds(848, 150, 30, 66);
                            pass1 = 8;
                            Map.this.setExtendedState(JFrame.HIDE_ON_CLOSE);
                        }
                    }
                }
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                if (jlbStage8.getIcon() != iconEnemyC && jlbStage7.getIcon() == iconQuestC) {
                    jlbStage8.setIcon(iconEnemyR);
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                if (jlbStage8.getIcon() != iconEnemyC && jlbStage7.getIcon() == iconQuestC) {
                    jlbStage8.setIcon(iconEnemyB);
                }

            }
        });

        jlbStage9.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                if (jlbStage8.getIcon() == iconEnemyC) {
                    if (e.getClickCount() == 1) {
                        if (jlbStage9.getIcon() != iconBoxC) {
                            Box9 b9 = new Box9(Map.this);
                            b9.setVisible(true);
                            Map.this.setVisible(false);
                            jlbStage9.setBounds(825, 224, 75, 79);
                            jlbStage9.setIcon(iconBoxC);
                            jlbStage10.setBounds(925, 234, 76, 59);
                            jlbStage10.setIcon(iconEnemyB);
                            pointerImg.setBounds(948, 150, 30, 66);
                            pass1 = 9;
                            Map.this.setExtendedState(JFrame.HIDE_ON_CLOSE);
                        }
                    }
                }
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                if (jlbStage9.getIcon() != iconBoxC && jlbStage8.getIcon() == iconEnemyC) {
                    jlbStage9.setIcon(iconBoxR);
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                if (jlbStage9.getIcon() != iconBoxC && jlbStage8.getIcon() == iconEnemyC) {
                    jlbStage9.setIcon(iconBoxB);
                }

            }
        });
        jlbStage10.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                if (jlbStage9.getIcon() == iconBoxC) {
                    if (e.getClickCount() == 1) {
                        if (jlbStage10.getIcon() != iconsEnemyC) {
                            sEnemy10 sEn2 = new sEnemy10(Map.this);
                            sEn2.setVisible(true);
                            Map.this.setVisible(false);
                            jlbStage10.setBounds(925, 224, 76, 79);
                            jlbStage10.setIcon(iconEnemyC);
                            jlbStage11.setBounds(1026, 228, 74, 70);
                            jlbStage11.setIcon(iconShopB);
                            pointerImg.setBounds(1048, 150, 30, 66);
                            pass1 = 10;
                            Map.this.setExtendedState(JFrame.HIDE_ON_CLOSE);
                        }
                    }
                }
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                if (jlbStage10.getIcon() != iconsEnemyC && jlbStage9.getIcon() == iconBoxC) {
                    jlbStage10.setIcon(iconsEnemyR);
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                if (jlbStage10.getIcon() != iconsEnemyC && jlbStage9.getIcon() == iconBoxC) {
                    jlbStage10.setIcon(iconsEnemyB);
                }

            }
        });
        jlbStage11.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                if (jlbStage10.getIcon() == iconsEnemyC) {
                    if (e.getClickCount() == 1) {
                        if (jlbStage11.getIcon() != iconShopC) {
                            Shop11 s11 = new Shop11(Map.this);
                            s11.setVisible(true);
                            Map.this.setVisible(false);
                            jlbStage11.setBounds(1023, 224, 80, 77);
                            jlbStage11.setIcon(iconShopC);
                            jlbStage12.setBounds(1134, 219, 59, 88);
                            jlbStage12.setIcon(iconQuestB);
                            pointerImg.setBounds(1148, 150, 30, 66);
                            pass1 = 11;
                            Map.this.setExtendedState(JFrame.HIDE_ON_CLOSE);
                        }
                    }
                }
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                if (jlbStage11.getIcon() != iconShopC && jlbStage10.getIcon() == iconsEnemyC) {
                    jlbStage11.setIcon(iconShopR);
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                if (jlbStage11.getIcon() != iconShopC && jlbStage10.getIcon() == iconsEnemyC) {
                    jlbStage11.setIcon(iconShopB);
                }

            }
        });

        jlbStage12.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                if (jlbStage11.getIcon() == iconShopC) {
                    if (e.getClickCount() == 1) {
                        if (jlbStage12.getIcon() != iconQuestC) {
                            Quest12 q12 = new Quest12(Map.this);
                            q12.setVisible(true);
                            Map.this.setVisible(false);
                            jlbStage12.setBounds(1125, 224, 79, 78);
                            jlbStage12.setIcon(iconQuestC);
                            jlbStage13.setBounds(1225, 228, 77, 81);
                            jlbStage13.setIcon(iconRestB);
                            pointerImg.setBounds(1248, 150, 30, 66);
                            pass1 = 12;
                            Map.this.setExtendedState(JFrame.HIDE_ON_CLOSE);
                        }
                    }
                }
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                if (jlbStage12.getIcon() != iconQuestC && jlbStage11.getIcon() == iconShopC) {
                    jlbStage12.setIcon(iconQuestR);
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                if (jlbStage12.getIcon() != iconQuestC && jlbStage11.getIcon() == iconShopC) {
                    jlbStage12.setIcon(iconQuestB);
                }

            }
        });

        jlbStage13.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                if (jlbStage12.getIcon() == iconQuestC) {
                    if (e.getClickCount() == 1) {
                        if (jlbStage13.getIcon() != iconRestC) {
                            Rest13 r13 = new Rest13(Map.this);
                            r13.setVisible(true);
                            Map.this.setVisible(false);
                            jlbStage13.setBounds(1227, 220, 80, 79);
                            jlbStage13.setIcon(iconRestC);
                            jlbStage14.setBounds(1332, 232, 62, 63);
                            jlbStage14.setIcon(iconEnemyB);
                            pointerImg.setBounds(1348, 150, 30, 66);
                            pass1 = 13;
                            Map.this.setExtendedState(JFrame.HIDE_ON_CLOSE);
                        }
                    }
                }
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                if (jlbStage13.getIcon() != iconRestC && jlbStage12.getIcon() == iconQuestC) {
                    jlbStage13.setIcon(iconRestR);
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                if (jlbStage13.getIcon() != iconRestC && jlbStage12.getIcon() == iconQuestC) {
                    jlbStage13.setIcon(iconRestB);
                }

            }
        });

        jlbStage14.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                if (jlbStage13.getIcon() == iconRestC) {
                    if (e.getClickCount() == 1) {
                        if (jlbStage14.getIcon() != iconEnemyC) {
                            Enemy14 en14 = new Enemy14(Map.this);
                            en14.setVisible(true);
                            Map.this.setVisible(false);
                            jlbStage14.setBounds(1325, 224, 76, 79);
                            jlbStage14.setIcon(iconEnemyC);
                            jlbStage15.setBounds(1425, 228, 77, 81);
                            jlbStage15.setIcon(iconRestB);
                            pointerImg.setBounds(1448, 150, 30, 66);
                            pass1 = 14;
                            Map.this.setExtendedState(JFrame.HIDE_ON_CLOSE);
                        }
                    }
                }
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                if (jlbStage14.getIcon() != iconEnemyC && jlbStage13.getIcon() == iconRestC) {
                    jlbStage14.setIcon(iconEnemyR);
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                if (jlbStage14.getIcon() != iconEnemyC && jlbStage13.getIcon() == iconRestC) {
                    jlbStage14.setIcon(iconEnemyB);
                }

            }
        });
        jlbStage15.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                if (jlbStage14.getIcon() == iconEnemyC) {
                    if (e.getClickCount() == 1) {
                        if (jlbStage15.getIcon() != iconRestC) {
                            Rest15 r15 = new Rest15(Map.this);
                            r15.setVisible(true);
                            Map.this.setVisible(false);
                            jlbStage15.setBounds(1423, 224, 80, 79);
                            jlbStage15.setSize(80, 79);
                            jlbStage15.setIcon(iconEnemyC);
                            pointerImg.setVisible(false);
                            pass1 = 15;
                            Map.this.setExtendedState(JFrame.HIDE_ON_CLOSE);
                        }
                    }
                }
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                if (jlbStage15.getIcon() != iconRestC && jlbStage14.getIcon() == iconEnemyC) {
                    jlbStage15.setIcon(iconRestR);
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                if (jlbStage15.getIcon() != iconRestC && jlbStage14.getIcon() == iconEnemyC) {
                    jlbStage15.setIcon(iconRest);
                }

            }
        });
        jlbStageBoss.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
//                if (jlbStage15.getIcon() == iconRestC) {
                    if (e.getClickCount() == 1){

                Boss16 boss = new Boss16(Map.this);
                boss.setVisible(true);
                Map.this.setVisible(false);
                pass1 = 16;
            }
                }
//            }

            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                if (jlbStage15.getIcon() == iconRestC) {
                    jlbStageBoss.setIcon(iconBossR);
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                if (jlbStage15.getIcon() == iconRestC) {
                    jlbStageBoss.setIcon(iconBoss);
                }

            }
        });
        mapImg.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                Map2 mp2 = new Map2();
                mp2.setVisible(true);
            }
        });
        settingImg.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                jpnSetting.setVisible(true);
                jpnC.setVisible(false);
            }
        });
        jbtAbout.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jpnAbout.setVisible(true);
                jpnSetting.setVisible(false);

            }
        });
        jbtRename.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jpnRename.setVisible(true);
                jpnSetting.setVisible(false);
            }
        });
        jbtRetry.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Map.this.setVisible(false);
                character c1 = new character();
                c1.setVisible(true);
            }
        });
        jbtClose.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showConfirmDialog(null,"Click to Close", "End", JOptionPane.YES_NO_OPTION);
                System.exit(0);
            }
        });
        jbtConfirmSetting.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jpnSetting.setVisible(false);
                jpnC.setVisible(true);
            }
        });
        jbtConfirmAbout.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jpnAbout.setVisible(false);
                jpnSetting.setVisible(true);
            }
        });
        jbtConfirmRename.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jlbName.setText(jtfRename.getText());
                nameLength = jtfRename.getText().length() * 65;
                roleLength = jtfRename.getText().length() * 65/2 +50;
                jlbName.setBounds(10,7,nameLength,65);
                jlbRole.setBounds(roleLength,23,150,40);
                jpnRename.setVisible(false);
                jpnSetting.setVisible(true);
            }
        });
        cardImg.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                jpnCard.removeAll();
                for (int i = 0; i < VA.size(); i++){
                    int x = 0;
                    if (i % 4 == 0){
                        x = 0;
                    }else if (i % 4 == 1){
                        x = 177;
                    }else if (i % 4 == 2){
                        x = 354;
                    }else if (i % 4 == 3){
                        x = 531;
                    }
                    int y = i/4 * 230;
                    System.out.println(x);
                    System.out.println(y);
                    System.out.println(VA.get(i).jlbMapCard.getIcon());
                    jpnCard.add(VA.get(i).jlbMapCard);
                    VA.get(i).jlbMapCard.setBounds(x, y, 157, 210);
                }
                jpnCard.repaint();
                jpnCard.revalidate();

                jpnCard.setVisible(true);
                jpnCard2.setVisible(true);
                jsp.setVisible(true);
                jpnC.setVisible(false);
                jbtConfirmCard.setVisible(true);

            }
        });
        jbtConfirmCard.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jsp.setVisible(false);
                jpnCard2.setVisible(false);
                jpnC.setVisible(true);
                jbtConfirmCard.setVisible(false);
            }
        });
    }



}
