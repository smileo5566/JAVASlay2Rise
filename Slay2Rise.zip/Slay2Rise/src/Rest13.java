


import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.Timer;


public class Rest13 extends JFrame {
    private Container cp;
    public JFrame map;
    private JPanel jpnC = new JPanel();

    //    背景圖

    private JLabel jlbForest = new JLabel();
    //

    //    jpnTalk
    private JLabel jlbChooseA = new JLabel("你獲得了充足的休息 +30HP");
    private JLabel jlbChooseB = new JLabel("離開");



    public Rest13(JFrame jFrame){
        init(jFrame);
    }
    public void init(JFrame jFrame){
        this.setBounds(150,100,1600,850);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.map = jFrame;
        cp = this.getContentPane();
        cp.setLayout(null);
        cp.add(jpnC);
//        jpnTalk
        jpnC.setBounds(0,0,1600,850);
        jpnC.setBackground(Color.BLACK);
        jpnC.setLayout(null);
        jpnC.add(jlbChooseA);
        jpnC.add(jlbChooseB);
        jlbChooseA.setBounds(0,0,1600,425);
        jlbChooseB.setBounds(0,425,1600,425);
        jlbChooseA.setFont(MyFont.WeiRuan60);
        jlbChooseB.setFont(MyFont.WeiRuan60);
        jlbChooseA.setForeground(Color.white);
        jlbChooseB.setForeground(Color.white);
        jlbChooseA.setHorizontalAlignment(SwingConstants.CENTER);
        jlbChooseA.setVerticalAlignment(SwingConstants.CENTER);
        jlbChooseB.setHorizontalAlignment(SwingConstants.CENTER);
        jlbChooseB.setVerticalAlignment(SwingConstants.CENTER);


//        jpnC
        jpnC.setBounds(0,0,1600,850);
        jpnC.setLayout(null);
        jpnC.add(jlbForest);

        jlbChooseB.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                Map.heartInt += 30;
                if (Map.heartInt > 100){
                    Map.heartInt = 100;
                }
                Map.jlbHeartInt.setText(Integer.toString(Map.heartInt));
                map.setExtendedState(JFrame.NORMAL);
                Rest13.this.setVisible(false);
            }
        });






    }
}













