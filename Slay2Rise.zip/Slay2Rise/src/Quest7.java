


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.Timer;


public class Quest7 extends Level{
    //    monster img
    private ImageIcon iconPig = new ImageIcon("img/Monster/pig.png");
    private ImageIcon iconFatPig = new ImageIcon("img/Monster/fatPig.png");
    private JPanel jpnAsk = new JPanel();
    private JLabel jlbTalk1 = new JLabel("<html><body><p>這隻豬看起來打不太死，要跟他對話試試看嗎?</p></body></html>");
    private JLabel jlbChooseA = new JLabel("踢他一腳");
    private JLabel jlbChooseB = new JLabel("打他一拳");
    private JLabel jlbChooseC = new JLabel("射他一箭");
    private JLabel jlbChooseD = new JLabel("對話");
    private JLabel jlbConfirm = new JLabel("確認");
    private JLabel jlbConfirm2 = new JLabel("離開");
    private JLabel jlbAskPig = new JLabel();

    //
    int MonsterWeak = 0;
    int MonsterHurt = 0;
    int AsheHurt = 0;
    int AsheWeak = 0;
    int AsheStr = 0;

    //    人物資料
    public static int getMoney = 70;
    public static int getMoney2 = 30;
    public static int AsheHp = Map.heartInt;
    private int monsterHp = 999;
    private int monsterHpChange;
    private int AsheHpChange;
    private int power = 3;
    int MonserAtk  = 1;
    int Shield = 0;

//


    public Quest7(JFrame jFrame){
        super(jFrame);
        init();
    }
    public void init(){
        background.add(jpnAsk);
        jlbMonster.setLocation(1000,330);
        jlbMonster.setSize(68,40);
        jlbMonsterAtk.setText("<html><body><p>這隻肥豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬將對你造成1點傷害</p></body></html>");
        jpnAsk.setBackground(new Color(0,0,0));
        jpnAsk.setBounds(100,100,1400,650);
        jpnAsk.setLayout(null);
        jpnAsk.add(jlbTalk1);
        jpnAsk.add(jlbChooseA);
        jpnAsk.add(jlbChooseB);
        jpnAsk.add(jlbChooseC);
        jpnAsk.add(jlbChooseD);
        jpnAsk.add(jlbConfirm);
        jpnAsk.add(jlbConfirm2);
        jpnAsk.add(jlbAskPig);
        jlbTalk1.setBounds(300,0,800,325);
        jlbAskPig.setBounds(800,200,68,40);
        jlbChooseA.setBounds(0,325,700,162);
        jlbChooseB.setBounds(0,488,700,162);
        jlbChooseC.setBounds(700,325,700,162);
        jlbChooseD.setBounds(700,488,700,162);
        jlbConfirm.setBounds(350,488,700,162);
        jlbConfirm2.setBounds(350,488,700,162);
        jlbTalk1.setFont(MyFont.WeiRuan60);
        jlbChooseA.setFont(MyFont.WeiRuan60);
        jlbChooseB.setFont(MyFont.WeiRuan60);
        jlbChooseC.setFont(MyFont.WeiRuan60);
        jlbChooseD.setFont(MyFont.WeiRuan60);
        jlbConfirm.setFont(MyFont.WeiRuan60);
        jlbConfirm2.setFont(MyFont.WeiRuan60);
        jlbTalk1.setForeground(Color.white);
        jlbChooseA.setForeground(Color.white);
        jlbChooseB.setForeground(Color.white);
        jlbChooseC.setForeground(Color.white);
        jlbChooseD.setForeground(Color.white);
        jlbConfirm.setForeground(Color.white);
        jlbConfirm2.setForeground(Color.white);
        jlbTalk1.setHorizontalAlignment(SwingConstants.CENTER);
        jlbTalk1.setVerticalAlignment(SwingConstants.CENTER);
        jlbChooseA.setHorizontalAlignment(SwingConstants.CENTER);
        jlbChooseA.setVerticalAlignment(SwingConstants.CENTER);
        jlbChooseB.setHorizontalAlignment(SwingConstants.CENTER);
        jlbChooseB.setVerticalAlignment(SwingConstants.CENTER);
        jlbChooseC.setHorizontalAlignment(SwingConstants.CENTER);
        jlbChooseC.setVerticalAlignment(SwingConstants.CENTER);
        jlbChooseD.setHorizontalAlignment(SwingConstants.CENTER);
        jlbChooseD.setVerticalAlignment(SwingConstants.CENTER);
        jlbConfirm.setHorizontalAlignment(SwingConstants.CENTER);
        jlbConfirm.setVerticalAlignment(SwingConstants.CENTER);
        jlbConfirm.setVisible(false);
        jlbConfirm2.setHorizontalAlignment(SwingConstants.CENTER);
        jlbConfirm2.setVerticalAlignment(SwingConstants.CENTER);
        jlbConfirm2.setVisible(false);
        jpnAsk.setVisible(false);

        jlbGetMoney.setText(Integer.toString(getMoney));
        jlbChoose2.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
               if (e.getClickCount() == 2){
                   Card card = new Card("命運之輪",ImageManager.iconCardAtk18);
                   Map.VA.add(card);
                   Map.heartInt = AsheHp;
                   Map.moneyInt += getMoney;
                   Map.jlbHeartInt.setText(Integer.toString(Map.heartInt));
                   Map.jlbMoneyInt.setText(Integer.toString(Map.moneyInt));
                   map.setExtendedState(JFrame.NORMAL);
                   Quest7.this.setVisible(false);
                   Map.cardInt = Map.VA.size();
                   Map.jlbCardInt.setText(Integer.toString(Map.cardInt));

               }
            }
        });
        jlbConfirm2.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                Map.heartInt = AsheHp;
                Map.moneyInt += getMoney2;
                Map.jlbHeartInt.setText(Integer.toString(Map.heartInt));
                Map.jlbMoneyInt.setText(Integer.toString(Map.moneyInt));
                map.setExtendedState(JFrame.NORMAL);
                Quest7.this.setVisible(false);
            }
        });
//        initialize
        jlbAsheHp.setText(Integer.toString(AsheHp));
        jlbAsheShield.setText(Integer.toString(Shield));
        jlbMonsterHp.setText(Integer.toString(monsterHp));

        jlbPower.setText(Integer.toString(power));
        jlbDeck.setText(Integer.toString(deck.size()));
        jlbDis.setText(Integer.toString(dis.size()));

//        怪物圖示
        iconPig = ImageManager.resize(iconPig, 68, 40, Image.SCALE_SMOOTH);
        iconFatPig = ImageManager.resize(iconFatPig, 183, 155, Image.SCALE_SMOOTH);
        jlbAskPig.setIcon(iconPig);
        jlbMonster.setIcon(iconPig);

//        設定最後選的牌

        jlbChoose1.setIcon(null);
        jlbChoose2.setIcon(ImageManager.resize(ImageManager.iconCardAtk18, 242,325, Image.SCALE_SMOOTH));
        jlbChoose3.setIcon(null);


//        choose

//        endbtn
        jbtEnd.addActionListener(new AbstractAction() {
            @Override

            public void actionPerformed(ActionEvent e) {
                jlbTurn.setForeground(Color.white);
                AsheHurt -= 1;
                AsheWeak -= 1;
                AsheStr -= 1;
                MonsterWeak -= 1;
                MonsterHurt -= 1;
                if (AsheStr <= 0){
                    AsheStr = 0;
                    jlbAsheStr.setVisible(false);
                }
                if (MonsterHurt <= 0){
                    MonsterHurt = 0;
                    jlbMonsterHurt.setVisible(false);
                }
                if (MonsterWeak <= 0){
                    MonsterWeak = 0;
                    jlbMonsterWeak.setVisible(false);
                }
                jpnHand.removeAll();
                repaint();
                revalidate();
                while (hand.size() != 0) {
                    dis.add(hand.remove(0));
                }
                jpnHand.setVisible(false);
                jlbDis.setText(Integer.toString(dis.size()));
                jlbDeck.setText(Integer.toString(deck.size()));
                jlbTurn.setText("敵方回合");
                jlbRound.setText("敵方回合");
                jlbRound.setVisible(true);
                jbtEnd.setEnabled(false);
                Timer timer1 = new Timer();
                timer1.schedule(new TimerTask() {
                    public void run() {
                        jlbRound.setVisible(false);
                    }
                }, 1000);

                timer1.schedule(new TimerTask() {
                    public void run() {
                                jlbMonster.setLocation(1030,330);
                    }
                }, 1500);
                timer1.schedule(new TimerTask() {
                    public void run() {
                                jlbMonster.setLocation(970,330);
                    }
                }, 1600);
                timer1.schedule(new TimerTask() {
                    public void run() {

                                jlbMonster.setLocation(1000,330);
                                jlbAshe.setLocation(220,270);
                                if (Shield >= (MonserAtk)){
                                    Shield = Shield - (MonserAtk);
                                    jlbAsheShield.setText(Integer.toString(Shield));
                                }else {
                                    jlbAsheShield.setText(Integer.toString(0));
                                    AsheHp = AsheHp - (MonserAtk - Shield);
                                    AsheHpChange = 0 - ( (MonserAtk) - Shield);
                                    if (MonserAtk >= AsheHp){
                                        jlbAsheHp.setText(Integer.toString(0));
                                    }
                                    jlbAsheHpChange.setVisible(true);
                                    jlbAsheHp.setText(Integer.toString(AsheHp));
                                    jlbAsheHpChange.setText(Integer.toString(AsheHpChange));
                                }
                    }
                }, 1700);
                timer1.schedule(new TimerTask() {
                    public void run() {
                                jlbAshe.setLocation(250,270);
                    }
                }, 1800);
                timer1.schedule(new TimerTask() {
                    public void run() {
                        if (AsheHp <= 0){
                            jlbLose.setVisible(true);
                        }else{
                            jlbAsheHpChange.setVisible(false);
                            jbtEnd.setEnabled(true);
                            jlbMonsterHpChange.setVisible(false);
                            jlbMonsterAtk.setText("這名敵人將造成"+ MonserAtk + "點傷害");
                            drawCard();
                            drawCard();
                            drawCard();
                            drawCard();
                            drawCard();
                            jlbDis.setText(Integer.toString(dis.size()));
                            jlbDeck.setText(Integer.toString(deck.size()));
                            jpnHand.setVisible(true);
                            power = 3;
                            jlbPower.setText(Integer.toString(power));
                            Shield = 0;
                            jlbAsheShield.setText(Integer.toString(Shield));
                            if (AsheWeak >= 0){
                                AsheWeak = 0;
                                jlbAsheWeak.setVisible(false);
                            }
                            if (AsheHurt >= 0){
                                jlbAsheHurt.setVisible(false);
                            }
                            jlbTurn.setText("你的回合");
                        }
                    }
                }, 2500);

            }

        });
        jlbMonster.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                jlbMonsterAtk.setVisible(true);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                jlbMonsterAtk.setVisible(false);
            }
            @Override
            public void mouseClicked(MouseEvent e){
                super.mouseClicked(e);
                jpnC.setVisible(false);
                jpnHand.setVisible(false);
                jpnInfo.setVisible(false);
                jbtEnd.setVisible(false);
                jpnAsk.setVisible(true);
            }
        });
        jlbChooseA.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                jlbTalk1.setText("大胖豬生氣了!");
                jlbAskPig.setLocation(670,310);
                monsterHp = 65;
                jlbMonsterHp.setText(Integer.toString(monsterHp));
                jlbChooseA.setVisible(false);
                jlbChooseB.setVisible(false);
                jlbChooseC.setVisible(false);
                jlbChooseD.setVisible(false);
                jlbConfirm.setVisible(true);
                jlbMonster.setBounds(1000,330,183,155);
                jlbMonster.setIcon(iconFatPig);
                MonserAtk = rdm1.nextInt((15)+1);
            }
        });
        jlbChooseB.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                jlbTalk1.setText("大胖豬生氣了!");
                jlbAskPig.setLocation(670,310);
                monsterHp = 65;
                jlbMonsterHp.setText(Integer.toString( monsterHp));
                jlbChooseA.setVisible(false);
                jlbChooseB.setVisible(false);
                jlbChooseC.setVisible(false);
                jlbChooseD.setVisible(false);
                jlbConfirm.setVisible(true);
                jlbMonster.setBounds(1000,330,183,155);
                jlbMonster.setIcon(iconFatPig);
                MonserAtk = rdm1.nextInt(20);
                jlbMonsterAtk.setText("<html><body><p>這隻肥豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬豬將對你造成</p></body></html>"+ MonserAtk +"<html><body><p>點傷害</p></body></html>");
            }
        });
        jlbChooseC.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                jlbTalk1.setText("大胖豬生氣了!");
                jlbAskPig.setLocation(670,310);
                monsterHp = 65;
                jlbMonsterHp.setText(Integer.toString(monsterHp));
                jlbChooseA.setVisible(false);
                jlbChooseB.setVisible(false);
                jlbChooseC.setVisible(false);
                jlbChooseD.setVisible(false);
                jlbConfirm.setVisible(true);
                jlbMonster.setBounds(1000,330,183,155);
                jlbMonster.setIcon(iconFatPig);
                MonserAtk = rdm1.nextInt(20);
            }
        });
        jlbChooseD.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                jlbTalk1.setText("大胖豬給了你一筆錢就走了");
                jlbAskPig.setLocation(670,310);
                jlbMonsterHp.setText(Integer.toString(65));
                jlbChooseA.setVisible(false);
                jlbChooseB.setVisible(false);
                jlbChooseC.setVisible(false);
                jlbChooseD.setVisible(false);
                jlbConfirm2.setVisible(true);
                jlbMonster.setBounds(1000,330,183,155);
                jlbMonster.setIcon(iconFatPig);
                MonserAtk = rdm1.nextInt(20);
                map.setExtendedState(JFrame.NORMAL);
            }
        });

        jlbConfirm.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                jpnAsk.setVisible(false);
                jpnC.setVisible(true);
                jpnHand.setVisible(true);
                jpnInfo.setVisible(true);
                jbtEnd.setVisible(true);

            }
        });
    }



//    以下都是 CardInteraction 的函式
//    因為有使用到一些我不確定的值(上面有提到 其實就是有些 enemy2有出現 enemy1沒出現)
//    所以還是要麻煩一點 每個 enemy 都寫

    @Override
    public void playGif(String cardName, int duration){
        if (cardName.equals("射擊!")){
            AsheGif.setBounds(500,270,197,191);
            AsheGif.setIcon(ImageManager.iconAtk1Gif);
        }else if (cardName.equals("守護!")){
            AsheGif.setBounds(500,270,261,271);
            AsheGif.setIcon(ImageManager.iconShield1Gif);
        }else if(cardName.equals("光明射擊")){
            AsheGif.setBounds(475,240,261,271);
            AsheGif.setIcon(ImageManager.iconAtk2Gif);
            Timer timer = new Timer();
            timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    jlbMonsterWeak.setVisible(true);
                }
            }, 1000);
        }else if (cardName.equals("光明箭矢")){
            AsheGif.setBounds(500,240,344,375);
            AsheGif.setIcon(ImageManager.iconAtk3Gif);
        }else if (cardName.equals("藍色牛角麵包")){
            AsheGif.setBounds(500,400,367,150);
            AsheGif.setIcon(ImageManager.iconAtk5Gif);
        }else if (cardName.equals("音速箭")){
            AsheGif.setBounds(500,270,99,40);
            AsheGif.setIcon(ImageManager.iconAtk6Gif);
        }else if (cardName.equals("烏龜頭箭")){
            AsheGif.setBounds(500,270,300,203);
            AsheGif.setIcon(ImageManager.iconAtk7Gif);
        }else if (cardName.equals("鐮刀小鬼")){
            AsheGif.setBounds(500,270,583,286);
            AsheGif.setIcon(ImageManager.iconAtk8Gif);
        }else if (cardName.equals("刃雨")){
            AsheGif.setBounds(500,270,245,220);
            AsheGif.setIcon(ImageManager.iconAtk9Gif);
        }else if (cardName.equals("捨命箭雨")){
            AsheGif.setBounds(500,270,573,442);
            AsheGif.setIcon(ImageManager.iconAtk10Gif);
        }else if (cardName.equals("精準的雞")){
            AsheGif.setBounds(500,270,126,184);
            AsheGif.setIcon(ImageManager.iconAtk11Gif);
        }else if (cardName.equals("牙籤之舞")){
            AsheGif.setBounds(500,270,573,442);
            AsheGif.setIcon(ImageManager.iconAtk10Gif);
        }else if (cardName.equals("感染")){
            AsheGif.setBounds(500,270,124,128);
            AsheGif.setIcon(ImageManager.iconAtk13Gif);
        }else if (cardName.equals("自體爆破")){
            AsheGif.setBounds(500,270,176,207);
            AsheGif.setIcon(ImageManager.iconAtk14Gif);
        }else if (cardName.equals("詛咒")){
            AsheGif.setBounds(500,270,423,150);
            AsheGif.setIcon(ImageManager.iconAtk15Gif);
        }else if (cardName.equals("BANG!")){
            AsheGif.setBounds(200,10,1076,718);
            AsheGif.setIcon(ImageManager.iconAtk16Gif);
        }else if (cardName.equals("鳥鳥打擊")){
            AsheGif.setBounds(500,270,126,165);
            AsheGif.setIcon(ImageManager.iconAtk17Gif);
        }else if (cardName.equals("命運之輪")){
            AsheGif.setBounds(500,270,261,250);
            AsheGif.setIcon(ImageManager.iconAtk18Gif);
        }else if (cardName.equals("禁咒")){
            AsheGif.setBounds(500,270,72,77);
            AsheGif.setIcon(ImageManager.iconBuff1Gif);
        }else if (cardName.equals("未知的力量")){
            AsheGif.setBounds(500,270,111,142);
            AsheGif.setIcon(ImageManager.iconBuff2Gif);
        }else if (cardName.equals("激發")){
            AsheGif.setBounds(500,270,136,185);
            AsheGif.setIcon(ImageManager.iconBuff3Gif);
        }else if (cardName.equals("好亮喔~~")) {
            AsheGif.setBounds(500,270, 171, 222);
            AsheGif.setIcon(ImageManager.iconBuff5Gif);
        }else if (cardName.equals("湖中女神")){
            AsheGif.setBounds(500,270,276,385);
            AsheGif.setIcon(ImageManager.iconBuff4Gif);
        }else if (cardName.equals("神聖之盾")){
            AsheGif.setBounds(500,270,332,328);
            AsheGif.setIcon(ImageManager.iconShield2Gif);
        }else if (cardName.equals("捨棄之盾")){
            AsheGif.setBounds(500,270,160,204);
            AsheGif.setIcon(ImageManager.iconShield3Gif);
        }else if (cardName.equals("天使祝福")){
            AsheGif.setBounds(500,270,512,371);
            AsheGif.setIcon(ImageManager.iconShield4Gif);
        }else if (cardName.equals("齒輪長翅膀")){
            AsheGif.setBounds(500,270,368,346);
            AsheGif.setIcon(ImageManager.iconShield5Gif);
        }
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                AsheGif.setIcon(null);
            }
        }, duration);
    }

    @Override
    public void useEnergy(int energy) {
        power -= energy;
        jlbPower.setText(Integer.toString(power));
    }

    @Override
    public void attack(int damage) {
        if (MonsterWeak > 0){
            damage *= 1.5f;
        }
        monsterHpChange = 0 - damage;
        monsterHp += monsterHpChange;

        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                jlbMonsterHpChange.setText(Integer.toString(monsterHpChange));
                jlbMonsterHp.setText(Integer.toString(monsterHp));
                jlbMonsterHpChange.setVisible(true);
                jlbMonster.setLocation(1030,330);
                if (monsterHp <= 0){
                    jlbMonsterHp.setText("0");
                    jpnHand.setVisible(false);
                    timer.schedule(new TimerTask() {
                        @Override
                        public void run() {
                            if (monsterHp <= 0){
                                jpnWin.setVisible(true);
                                jbtEnd.setEnabled(false);
                            }
                        }
                    },1500);
                }
            }
        },1000);
        timer.schedule(new TimerTask() {
            @Override
            public void run() {

                jlbMonster.setLocation(1000,330);
            }
        },1100);
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                jlbMonsterHpChange.setVisible(false);

            }
        },1500);

    }

    @Override
    public void heal(int health) {
        monsterHp += health;
        monsterHpChange = health;
        jlbMonsterHpChange.setText(Integer.toString(monsterHpChange));
        monsterHpChange = 0;
        jlbMonsterHp.setText(Integer.toString(Shield));
    }

    @Override
    public void addShield(int shield) {
        Shield += shield;
        jlbAsheShield.setText(Integer.toString(Shield));
    }

    @Override
    public void addStatus(String status, int round) {
        if (status.equals("weak")){
            MonsterWeak += round;
        }
        if (status.equals("hurt")){
            MonsterHurt += round;
        }
        if (status.equals("str")){
            AsheStr += 1;
        }

        if (status.equals("AsheWeak")){
            AsheWeak += round;
        }

    }

    @Override
    public void drawCard(int card) {
        drawCard();
    }

    @Override
    public void putCard2Dis(Card card) {
        hand.remove(card);
        dis.add(card);
        jpnHand.remove(card.jlbGameCard);
        jpnHand.repaint();
        jpnHand.revalidate();
        jlbDeck.setText(Integer.toString(deck.size()));
        jlbDis.setText(Integer.toString(dis.size()));
    }

    @Override
    public void setWarning(String warning) {
        jlbTurn.setVisible(true);
        jlbTurn.setBounds(650,0,300,80);
        jlbTurn.setForeground(Color.red);
        jlbTurn.setText(warning);
    }

    @Override
    public int getHP() {
        return AsheHp;
    }

    @Override
    public int getShield() {
        return Shield;
    }

    @Override
    public int getEnergy() {
        return power;
    }

}


