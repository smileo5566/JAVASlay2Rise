import javax.swing.*;
import java.awt.*;

public class ImageManager {
    //    所有卡牌
    public static ImageIcon iconCardAtk1 = new ImageIcon("img/Card/cardAtk1.png");
    public static ImageIcon iconCardAtk2 = new ImageIcon("img/Card/cardAtk2.png");
    public static ImageIcon iconCardAtk3 = new ImageIcon("img/Card/cardAtk3.png");
    public static ImageIcon iconCardAtk4 = new ImageIcon("img/Card/cardAtk4.png");
    public static ImageIcon iconCardAtk5 = new ImageIcon("img/Card/cardAtk5.png");
    public static ImageIcon iconCardAtk6 = new ImageIcon("img/Card/cardAtk6.png");
    public static ImageIcon iconCardAtk7 = new ImageIcon("img/Card/cardAtk7.png");
    public static ImageIcon iconCardAtk8 = new ImageIcon("img/Card/cardAtk8.png");
    public static ImageIcon iconCardAtk9 = new ImageIcon("img/Card/cardAtk9.png");
    public static ImageIcon iconCardAtk10 = new ImageIcon("img/Card/cardAtk10.png");
    public static ImageIcon iconCardAtk11 = new ImageIcon("img/Card/cardAtk11.png");
    public static ImageIcon iconCardAtk12 = new ImageIcon("img/Card/cardAtk12.png");
    public static ImageIcon iconCardAtk13 = new ImageIcon("img/Card/cardAtk13.png");
    public static ImageIcon iconCardAtk14 = new ImageIcon("img/Card/cardAtk14.png");
    public static ImageIcon iconCardAtk15 = new ImageIcon("img/Card/cardAtk15.png");
    public static ImageIcon iconCardAtk16 = new ImageIcon("img/Card/cardAtk16.png");
    public static ImageIcon iconCardAtk17 = new ImageIcon("img/Card/cardAtk17.png");
    public static ImageIcon iconCardAtk18 = new ImageIcon("img/Card/cardAtk18.png");
    public static ImageIcon iconCardBuff1 = new ImageIcon("img/Card/cardBuff1.png");
    public static ImageIcon iconCardBuff2 = new ImageIcon("img/Card/cardBuff2.png");
    public static ImageIcon iconCardBuff3 = new ImageIcon("img/Card/cardBuff3.png");
    public static ImageIcon iconCardBuff4 = new ImageIcon("img/Card/cardBuff4.png");
    public static ImageIcon iconCardBuff5 = new ImageIcon("img/Card/cardBuff5.png");
    public static ImageIcon iconCardShield1 = new ImageIcon("img/Card/cardShield1.png");
    public static ImageIcon iconCardShield2 = new ImageIcon("img/Card/cardShield2.png");
    public static ImageIcon iconCardShield3 = new ImageIcon("img/Card/cardShield3.png");
    public static ImageIcon iconCardShield4 = new ImageIcon("img/Card/cardShield4.png");
    public static ImageIcon iconCardShield5 = new ImageIcon("img/Card/cardShield5.png");
    public static ImageIcon iconCardInjure = new ImageIcon("img/Card/cardInjure.png");

    //    卡牌gif
    public static ImageIcon iconAtk1Gif = new ImageIcon("img/Card/atk1Gif.gif");
    public static ImageIcon iconAtk2Gif = new ImageIcon("img/Card/atk2Gif.gif");
    public static ImageIcon iconAtk3Gif = new ImageIcon("img/Card/atk3Gif.gif");
    public static ImageIcon iconAtk4Gif = new ImageIcon("img/Card/atk4Gif.gif");
    public static ImageIcon iconAtk5Gif = new ImageIcon("img/Card/atk5Gif.gif");
    public static ImageIcon iconAtk6Gif = new ImageIcon("img/Card/atk6Gif.gif");
    public static ImageIcon iconAtk7Gif = new ImageIcon("img/Card/atk7Gif.gif");
    public static ImageIcon iconAtk8Gif = new ImageIcon("img/Card/atk8Gif.gif");
    public static ImageIcon iconAtk9Gif = new ImageIcon("img/Card/atk9Gif.gif");
    public static ImageIcon iconAtk10Gif = new ImageIcon("img/Card/atk10Gif.gif");
    public static ImageIcon iconAtk11Gif = new ImageIcon("img/Card/atk11Gif.gif");
    public static ImageIcon iconAtk12Gif = new ImageIcon("img/Card/atk12Gif.gif");
    public static ImageIcon iconAtk13Gif = new ImageIcon("img/Card/atk13Gif.gif");
    public static ImageIcon iconAtk14Gif = new ImageIcon("img/Card/atk14Gif.gif");
    public static ImageIcon iconAtk15Gif = new ImageIcon("img/Card/atk15Gif.gif");
    public static ImageIcon iconAtk16Gif = new ImageIcon("img/Card/atk16Gif.gif");
    public static ImageIcon iconAtk17Gif = new ImageIcon("img/Card/atk17Gif.gif");
    public static ImageIcon iconAtk18Gif = new ImageIcon("img/Card/atk18Gif.gif");
    public static ImageIcon iconShield1Gif = new ImageIcon("img/Card/shield1Gif.gif");
    public static ImageIcon iconShield2Gif = new ImageIcon("img/Card/shield2Gif.gif");
    public static ImageIcon iconShield3Gif = new ImageIcon("img/Card/shield3Gif.gif");
    public static ImageIcon iconShield4Gif = new ImageIcon("img/Card/shield4Gif.gif");
    public static ImageIcon iconShield5Gif = new ImageIcon("img/Card/shield5Gif.gif");
    public static ImageIcon iconBuff1Gif = new ImageIcon("img/Card/buff1Gif.gif");
    public static ImageIcon iconBuff2Gif = new ImageIcon("img/Card/buff2Gif.gif");
    public static ImageIcon iconBuff3Gif = new ImageIcon("img/Card/buff3Gif.gif");
    public static ImageIcon iconBuff4Gif = new ImageIcon("img/Card/buff4Gif.gif");
    public static ImageIcon iconBuff5Gif = new ImageIcon("img/Card/buff5Gif.gif");
    // 其他圖片
    public static ImageIcon iconAshe = new ImageIcon("img/Ashe.png");
    public static ImageIcon iconCard = new ImageIcon("img/Card.png");
    public static ImageIcon iconWeak = new ImageIcon("img/weak.png");
    public static ImageIcon iconHurt = new ImageIcon("img/hurt.png");
    public static ImageIcon iconStr = new ImageIcon("img/strength1.png");
    public static ImageIcon iconForest = new ImageIcon("img/forest.jpg");
    public static ImageIcon iconMoney = new ImageIcon("img/money.png");
    public static ImageIcon iconGoldenPig = new ImageIcon("img/Monster/goldenPig.png");
    public static ImageIcon iconHeart = new ImageIcon("img/heart.png");
    public static ImageIcon iconMap = new ImageIcon("img/map.png");
    public static ImageIcon iconSetting = new ImageIcon("img/setting.png");
    public static ImageIcon iconCardHeal = new ImageIcon("img/Card/cardHeal.png");
    public static ImageIcon iconCardRecycle = new ImageIcon("img/Card/cardRecycle.png");


    //   縮放圖片 ( 要縮放的圖片, 縮放後的寬度, 縮放後的高度, 縮放的方式(Image_SMOOTH Image_DEFAULT )
    public static ImageIcon resize(ImageIcon imageIcon, int width, int height, int hints) {
        Image image = imageIcon.getImage().getScaledInstance(width, height, hints);
        return new ImageIcon(image);
    }
}
