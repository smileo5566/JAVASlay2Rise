public interface CardInteraction {  // 卡牌互動的介面

    void playGif(String cardName, int duration);

//    花費能量
    void useEnergy(int energy);

//    造成傷害
    void attack(int damage);

//    health
    void heal(int health);

//    addShield
    void addShield(int shield);

    void addStatus(String status, int round);

//    card
    void drawCard(int card);

//    將那張牌放入 dix
    void putCard2Dis(Card card);

    int getHP();

    int getShield();

    int getEnergy();

    void setWarning(String warning);



}
