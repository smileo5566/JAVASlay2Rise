


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.Timer;


public class Enemy2 extends Level{
//    monster img
    private ImageIcon iconGreen = new ImageIcon("img/Monster/green.png");
    private ImageIcon iconBlue = new ImageIcon("img/Monster/blue.png");

//
    int MonsterWeak = 0;
    int MonsterHurt = 0;
    int AsheHurt = 0;
    int AsheWeak = 0;
    int AsheStr = 0;
    int Round = 1;
    int a = Round % 3 ;

    //    人物資料
    public static int getMoney = 50;
    public static int AsheHp = Map.heartInt;
    private int monsterHp = 50;
    private int monsterHpChange;
    private int AsheHpChange;
    private int power = 3;
    int MonserAtk  = 15;
    int Shield = 0;

    public Enemy2(JFrame jFrame){
        super(jFrame);
        init();
    }
    public void init(){
//        initialize
        jlbAsheHp.setText(Integer.toString(AsheHp));
        jlbAsheShield.setText(Integer.toString(Shield));
        jlbMonsterHp.setText(Integer.toString(monsterHp));

        jlbPower.setText(Integer.toString(power));
        jlbDeck.setText(Integer.toString(deck.size()));
        jlbDis.setText(Integer.toString(dis.size()));

//        怪物圖示
        iconGreen = ImageManager.resize(iconGreen, 226, 156, Image.SCALE_SMOOTH);
        iconBlue = ImageManager.resize(iconBlue, 226, 156, Image.SCALE_SMOOTH);
        jlbMonster.setIcon(iconGreen);

//        設定最後選的牌
        jlbChoose1.setIcon(ImageManager.resize(ImageManager.iconCardShield3, 242,325, Image.SCALE_SMOOTH));
        jlbChoose2.setIcon(ImageManager.resize(ImageManager.iconCardShield2, 242,325, Image.SCALE_SMOOTH));
        jlbChoose3.setIcon(ImageManager.resize(ImageManager.iconCardAtk4, 242,325, Image.SCALE_SMOOTH));

//        敵人行為
        int i = rdm1.nextInt((10) );
        switch (a)
        {
            case 1 :
                jlbMonsterAtk.setText("這名敵人將轉變型態");
                break;
            case 2 :
                int a = MonserAtk + i;
                jlbMonsterAtk.setText("這名敵人將造成"+ a + "點傷害");
                break;
            case 0 :
                jlbMonsterAtk.setText("Heal!");
                break;
        }

//        choose
        jlbChoose1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2){
                    Card card = new Card("捨棄之盾",ImageManager.iconCardShield3);
                    Map.VA.add(card);
                    Map.heartInt = AsheHp;
                    Map.moneyInt += getMoney;
                    Map.jlbHeartInt.setText(Integer.toString(Map.heartInt));
                    Map.jlbMoneyInt.setText(Integer.toString(Map.moneyInt));
                    jlbGetMoney.setText(Integer.toString(getMoney));
                    map.setExtendedState(JFrame.NORMAL);
                    Enemy2.this.setVisible(false);
                    Map.cardInt = Map.VA.size();
                    Map.jlbCardInt.setText(Integer.toString(Map.cardInt));
                }
            }
        });
        jlbChoose2.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2){
                    Card card = new Card("神聖之盾",ImageManager.iconCardShield2);
                    Map.VA.add(card);
                    Map.heartInt = AsheHp;
                    Map.moneyInt += getMoney;
                    Map.jlbHeartInt.setText(Integer.toString(Map.heartInt));
                    jlbGetMoney.setText(Integer.toString(getMoney));
                    Map.jlbMoneyInt.setText(Integer.toString(Map.moneyInt));
                    Map.cardInt = Map.VA.size();
                    Map.jlbCardInt.setText(Integer.toString(Map.cardInt));
                    map.setExtendedState(JFrame.NORMAL);
                    Enemy2.this.setVisible(false);

                }
            }
        });
        jlbChoose3.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2){
                    Card card = new Card("聖盾射擊",ImageManager.iconCardAtk4);
                    Map.VA.add(card);
                    Map.heartInt = AsheHp;
                    Map.moneyInt += getMoney;
                    jlbGetMoney.setText(Integer.toString(getMoney));
                    Map.jlbHeartInt.setText(Integer.toString(Map.heartInt));
                    Map.jlbMoneyInt.setText(Integer.toString(Map.moneyInt));
                    map.setExtendedState(JFrame.NORMAL);
                    Enemy2.this.setVisible(false);
                    Map.cardInt = Map.VA.size();
                    Map.jlbCardInt.setText(Integer.toString(Map.cardInt));
                }
            }
        });
//        endbtn
        jbtEnd.addActionListener(new AbstractAction() {
            @Override

            public void actionPerformed(ActionEvent e) {
                jlbTurn.setForeground(Color.white);
                AsheHurt -= 1;
                AsheWeak -= 1;
                AsheStr -= 1;
                MonsterWeak -= 1;
                MonsterHurt -= 1;
                if (AsheStr <= 0){
                    AsheStr = 0;
                    jlbAsheStr.setVisible(false);
                }
                if (MonsterHurt <= 0){
                    MonsterHurt = 0;
                    jlbMonsterHurt.setVisible(false);
                }
                if (MonsterWeak <= 0){
                    MonsterWeak = 0;
                    jlbMonsterWeak.setVisible(false);
                }
                jpnHand.removeAll();
                repaint();
                revalidate();
                while (hand.size() != 0) {
                    dis.add(hand.remove(0));
                }
                jpnHand.setVisible(false);
                jlbDis.setText(Integer.toString(dis.size()));
                jlbDeck.setText(Integer.toString(deck.size()));
                jlbTurn.setText("敵方回合");
                jlbRound.setText("敵方回合");
                jlbRound.setVisible(true);
                jbtEnd.setEnabled(false);
                Timer timer1 = new Timer();
                timer1.schedule(new TimerTask() {
                    public void run() {
                        jlbRound.setVisible(false);
                    }
                }, 1000);

                timer1.schedule(new TimerTask() {
                    public void run() {
                        int a = Round % 3 ;
                        switch (a){
                            case 1 :
                                if (jlbMonster.getIcon() == iconGreen){
                                jlbMonster.setIcon(iconBlue);
                                }else {
                                    jlbMonster.setIcon(iconGreen);
                                }
                                break;
                            case 2 :
                                jlbMonster.setLocation(1030,270);
                                break;
                            case 0 :
                                jlbMonster.setLocation(1000,270);
                                break;
                        }
                    }
                }, 1500);
                timer1.schedule(new TimerTask() {
                    public void run() {
                        switch (a){
                            case 1 :
                                if (jlbMonster.getIcon() == iconGreen){
                                    jlbMonster.setIcon(iconGreen);
                                }else {
                                    jlbMonster.setIcon(iconBlue);
                                }
                                break;
                            case 2 :
                                jlbMonster.setLocation(970,270);
                                break;
                            case 0:
                                jlbMonster.setLocation(1000,270);
                                break;
                        }
                    }
                }, 1600);
                timer1.schedule(new TimerTask() {
                    public void run() {
                        switch (a){
                            case 1 :
                                if (jlbMonster.getIcon() == iconGreen){
                                    jlbMonster.setIcon(iconBlue);
                                }else {
                                    jlbMonster.setIcon(iconGreen);
                                }
                                break;
                            case 2 :
                                jlbMonster.setLocation(1000,270);
                                jlbAshe.setLocation(220,270);
                                if (Shield >= (MonserAtk + i)){
                                    Shield = Shield - (MonserAtk + i);
                                    jlbAsheShield.setText(Integer.toString(Shield));
                                }else {
                                    jlbAsheShield.setText(Integer.toString(0));
                                    AsheHp = AsheHp - ( (MonserAtk + i) - Shield);
                                    AsheHpChange = 0 - ( (MonserAtk + i) - Shield);
                                    if ( (MonserAtk + i) >= AsheHp){
                                        jlbAsheHp.setText(Integer.toString(0));
                                    }
                                    jlbAsheHpChange.setVisible(true);
                                    jlbAsheHp.setText(Integer.toString(AsheHp));
                                    jlbAsheHpChange.setText(Integer.toString(AsheHpChange));
                                }

                                break;
                            case 0 :
                                jlbMonster.setLocation(1000,270);
                                monsterHp += 30;
                                monsterHpChange += 30;
                                jlbMonsterHp.setText(Integer.toString(monsterHp));
                                jlbMonsterHpChange.setText("+" + Integer.toString(monsterHpChange));
                                jlbMonsterHpChange.setVisible(true);
                                break;
                        }

                    }
                }, 1700);
                timer1.schedule(new TimerTask() {
                    public void run() {
                        switch (a){
                            case 1 :
                                if (jlbMonster.getIcon() == iconGreen){
                                    jlbMonster.setIcon(iconGreen);
                                }else {
                                     jlbMonster.setIcon(iconBlue);
                                }
                                break;
                            case 2 :
                                jlbAshe.setLocation(250,270);
                                break;
                            case 0 :
                                jlbMonster.setLocation(1000,270);
                                break;
                        }
                    }
                }, 1800);
                timer1.schedule(new TimerTask() {
                    public void run() {
                        switch (a){
                            case 1 :
                                if (jlbMonster.getIcon() == iconGreen){
                                    jlbMonster.setIcon(iconBlue);
                                }else {
                                   jlbMonster.setIcon(iconGreen);
                                }
                                break;
                            case 2 :
                                break;
                            case 0 :
                                break;
                        }
                    }
                }, 1900);
                timer1.schedule(new TimerTask() {
                    public void run() {
                        if (AsheHp <= 0){
                            jlbLose.setVisible(true);
                        }else{
                            jlbAsheHpChange.setVisible(false);
                            jbtEnd.setEnabled(true);
                            jlbMonsterHpChange.setVisible(false);
                            Round ++;
                            a = Round % 3;

                            switch (a)
                            {
                                case 1 :
                                    jlbMonsterAtk.setText("這名敵人將轉變型態");
                                    break;
                                case 2 :
                                    int a = MonserAtk + i;
                                    jlbMonsterAtk.setText("這名敵人將造成"+ a + "點傷害");
                                    break;
                                case 0 :
                                    jlbMonsterAtk.setText("Heal!");
                                    break;
                            }
                            drawCard();
                            drawCard();
                            drawCard();
                            drawCard();
                            drawCard();
                            jlbDis.setText(Integer.toString(dis.size()));
                            jlbDeck.setText(Integer.toString(deck.size()));
                            jpnHand.setVisible(true);
                            power = 3;
                            jlbPower.setText(Integer.toString(power));
                            Shield = 0;
                            jlbAsheShield.setText(Integer.toString(Shield));
                            if (AsheWeak >= 0){
                                AsheWeak = 0;
                                jlbAsheWeak.setVisible(false);
                            }
                            if (AsheHurt >= 0){
                                jlbAsheHurt.setVisible(false);
                            }
                            jlbTurn.setText("你的回合");
                        }
                    }
                }, 2500);

            }

        });
        jlbMonster.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                jlbMonsterAtk.setVisible(true);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                jlbMonsterAtk.setVisible(false);
            }
        });
    }



//    以下都是 CardInteraction 的函式
//    因為有使用到一些我不確定的值(上面有提到 其實就是有些 enemy2有出現 enemy1沒出現)
//    所以還是要麻煩一點 每個 enemy 都寫

    @Override
    public void playGif(String cardName, int duration){
        if (cardName.equals("射擊!")){
            AsheGif.setBounds(500,270,197,191);
            AsheGif.setIcon(ImageManager.iconAtk1Gif);
        }else if (cardName.equals("守護!")){
            AsheGif.setBounds(500,270,261,271);
            AsheGif.setIcon(ImageManager.iconShield1Gif);
        }else if(cardName.equals("光明射擊")){
            AsheGif.setBounds(475,240,261,271);
            AsheGif.setIcon(ImageManager.iconAtk2Gif);
            Timer timer = new Timer();
            timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    jlbMonsterWeak.setVisible(true);
                }
            }, 1000);
        }else if (cardName.equals("光明箭矢")){
            AsheGif.setBounds(500,240,344,375);
            AsheGif.setIcon(ImageManager.iconAtk3Gif);
        }else if (cardName.equals("藍色牛角麵包")){
            AsheGif.setBounds(500,400,367,150);
            AsheGif.setIcon(ImageManager.iconAtk5Gif);
        }else if (cardName.equals("音速箭")){
            AsheGif.setBounds(500,270,99,40);
            AsheGif.setIcon(ImageManager.iconAtk6Gif);
        }else if (cardName.equals("烏龜頭箭")){
            AsheGif.setBounds(500,270,300,203);
            AsheGif.setIcon(ImageManager.iconAtk7Gif);
        }else if (cardName.equals("鐮刀小鬼")){
            AsheGif.setBounds(500,270,583,286);
            AsheGif.setIcon(ImageManager.iconAtk8Gif);
        }else if (cardName.equals("刃雨")){
            AsheGif.setBounds(500,270,245,220);
            AsheGif.setIcon(ImageManager.iconAtk9Gif);
        }else if (cardName.equals("捨命箭雨")){
            AsheGif.setBounds(500,270,573,442);
            AsheGif.setIcon(ImageManager.iconAtk10Gif);
        }else if (cardName.equals("精準的雞")){
            AsheGif.setBounds(500,270,126,184);
            AsheGif.setIcon(ImageManager.iconAtk11Gif);
        }else if (cardName.equals("牙籤之舞")){
            AsheGif.setBounds(500,270,573,442);
            AsheGif.setIcon(ImageManager.iconAtk10Gif);
        }else if (cardName.equals("感染")){
            AsheGif.setBounds(500,270,124,128);
            AsheGif.setIcon(ImageManager.iconAtk13Gif);
        }else if (cardName.equals("自體爆破")){
            AsheGif.setBounds(500,270,176,207);
            AsheGif.setIcon(ImageManager.iconAtk14Gif);
        }else if (cardName.equals("詛咒")){
            AsheGif.setBounds(500,270,423,150);
            AsheGif.setIcon(ImageManager.iconAtk15Gif);
        }else if (cardName.equals("BANG!")){
            AsheGif.setBounds(200,10,1076,718);
            AsheGif.setIcon(ImageManager.iconAtk16Gif);
        }else if (cardName.equals("鳥鳥打擊")){
            AsheGif.setBounds(500,270,126,165);
            AsheGif.setIcon(ImageManager.iconAtk17Gif);
        }else if (cardName.equals("命運之輪")){
            AsheGif.setBounds(500,270,261,250);
            AsheGif.setIcon(ImageManager.iconAtk18Gif);
        }else if (cardName.equals("禁咒")){
            AsheGif.setBounds(500,270,72,77);
            AsheGif.setIcon(ImageManager.iconBuff1Gif);
        }else if (cardName.equals("未知的力量")){
            AsheGif.setBounds(500,270,111,142);
            AsheGif.setIcon(ImageManager.iconBuff2Gif);
        }else if (cardName.equals("激發")){
            AsheGif.setBounds(500,270,136,185);
            AsheGif.setIcon(ImageManager.iconBuff3Gif);
        }else if (cardName.equals("好亮喔~~")) {
            AsheGif.setBounds(500,270, 171, 222);
            AsheGif.setIcon(ImageManager.iconBuff5Gif);
        }else if (cardName.equals("湖中女神")){
            AsheGif.setBounds(500,270,276,385);
            AsheGif.setIcon(ImageManager.iconBuff4Gif);
        }else if (cardName.equals("神聖之盾")){
            AsheGif.setBounds(500,270,332,328);
            AsheGif.setIcon(ImageManager.iconShield2Gif);
        }else if (cardName.equals("捨棄之盾")){
            AsheGif.setBounds(500,270,160,204);
            AsheGif.setIcon(ImageManager.iconShield3Gif);
        }else if (cardName.equals("天使祝福")){
            AsheGif.setBounds(500,270,512,371);
            AsheGif.setIcon(ImageManager.iconShield4Gif);
        }else if (cardName.equals("齒輪長翅膀")){
            AsheGif.setBounds(500,270,368,346);
            AsheGif.setIcon(ImageManager.iconShield5Gif);
        }
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                AsheGif.setIcon(null);
            }
        }, duration);
    }

    @Override
    public void useEnergy(int energy) {
        power -= energy;
        jlbPower.setText(Integer.toString(power));
    }

    @Override
    public void attack(int damage) {
        if (MonsterWeak > 0){
            damage *= 1.5f;
        }
        monsterHpChange = 0 - damage;
        monsterHp += monsterHpChange;

        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                jlbMonsterHpChange.setText(Integer.toString(monsterHpChange));
                jlbMonsterHp.setText(Integer.toString(monsterHp));
                jlbMonsterHpChange.setVisible(true);
                jlbMonster.setLocation(1030,270);
                if (monsterHp <= 0){
                    jlbMonsterHp.setText("0");
                    jpnHand.setVisible(false);
                    timer.schedule(new TimerTask() {
                        @Override
                        public void run() {
                            if (monsterHp <= 0){
                                jpnWin.setVisible(true);
                                jbtEnd.setEnabled(false);
                            }
                        }
                    },1500);
                }
            }
        },1000);
        timer.schedule(new TimerTask() {
            @Override
            public void run() {

                jlbMonster.setLocation(1000,270);
            }
        },1100);
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                jlbMonsterHpChange.setVisible(false);

            }
        },1500);

    }

    @Override
    public void heal(int health) {
        monsterHp += health;
        monsterHpChange = health;
        jlbMonsterHpChange.setText(Integer.toString(monsterHpChange));
        monsterHpChange = 0;
        jlbMonsterHp.setText(Integer.toString(Shield));
    }

    @Override
    public void addShield(int shield) {
        Shield += shield;
        jlbAsheShield.setText(Integer.toString(Shield));
    }

    @Override
    public void addStatus(String status, int round) {
        if (status.equals("weak")){
            MonsterWeak += round;
        }
        if (status.equals("hurt")){
            MonsterHurt += round;
        }
        if (status.equals("str")){
            AsheStr += 1;
        }

        if (status.equals("AsheWeak")){
            AsheWeak += round;
        }

    }

    @Override
    public void drawCard(int card) {
        drawCard();
    }

    @Override
    public void putCard2Dis(Card card) {
        hand.remove(card);
        dis.add(card);
        jpnHand.remove(card.jlbGameCard);
        jpnHand.repaint();
        jpnHand.revalidate();
        jlbDeck.setText(Integer.toString(deck.size()));
        jlbDis.setText(Integer.toString(dis.size()));
    }

    @Override
    public void setWarning(String warning) {
        jlbTurn.setVisible(true);
        jlbTurn.setBounds(650,0,300,80);
        jlbTurn.setForeground(Color.red);
        jlbTurn.setText(warning);
    }

    @Override
    public int getHP() {
        return AsheHp;
    }

    @Override
    public int getShield() {
        return Shield;
    }

    @Override
    public int getEnergy() {
        return power;
    }

}


