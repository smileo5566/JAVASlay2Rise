


import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.Timer;


public class Shop11 extends JFrame {
    private Container cp;
    public JFrame map;
    private JPanel jpnC = new JPanel();
    private JPanel jpnN = new JPanel();
    private JPanel jpnSetting = new JPanel();
    private  JPanel jpnAbout = new JPanel();
    private  JPanel jpnRename = new JPanel();
    private  JPanel jpnCard = new JPanel();
    private  JPanel jpnCard2 = new JPanel();
    private  JPanel jpnCardShop = new JPanel();
    private  JPanel jpnCardShop2 = new JPanel();
    private  JPanel jpnShop = new JPanel();
    private JScrollPane jsp = new JScrollPane(jpnCard);
    private JScrollBar Bar = jsp.getVerticalScrollBar();
    private JScrollPane jspShop = new JScrollPane(jpnCardShop);
    private JScrollBar BarShop = jsp.getVerticalScrollBar();

    //    背景圖

    private JLabel jlbForest = new JLabel();
    //
//    jpnC
    private JLabel jlbAshe = new JLabel();
    private JLabel jlbMonster = new JLabel();
    private JLabel jlbMonsterTalk = new JLabel("歡迎光臨");
    private JLabel jlbMonsterLabel = new JLabel("均一價50元!");
    private JLabel jlbShopMoney = new JLabel("你現在剩下" + moneyInt + "元");
    //    jpnN
    private JLabel moneyImg = new JLabel();
    private JLabel heartImg = new JLabel();
    private JLabel mapImg = new JLabel();
    private JLabel settingImg = new JLabel();
    public static int moneyInt = Map.moneyInt;
    public static int heartInt = Map.heartInt;
    private JLabel jlbHeartInt = new JLabel(Integer.toString(heartInt));
    private JLabel jlbMoneyInt = new JLabel(Integer.toString(moneyInt));

    int nameLength = character.JtfName.getText().length() * 65; //設定職業和暱稱距離
    int roleLength = character.JtfName.getText().length() * 65/2 + 50; //設定職業和暱稱距離

    public static JLabel jlbName = new JLabel(character.JtfName.getText());
    private JLabel jlbRole = new JLabel("神射手");

    private JButton jbtConfirmCard = new JButton("Confirm");
    //    jpnSetting
    private JButton jbtAbout = new JButton("About");
    private JButton jbtRename = new JButton("Rename");
    private JButton jbtRetry = new JButton("Retry");
    private JButton jbtClose = new JButton("End");
    private JButton jbtConfirmSetting = new JButton("Confirm");

    private JLabel jlbAbout = new JLabel("<html><body><p>作者 : 謝量 陳鼎超 王哲為</p><br><p>作品名 : Slay 2 Rise</p><br><p>發布日 : 2019/01/10</p><br><p>特別感謝: 林永隆 沒有他就沒有這個專題</p><body></html>");
    private JLabel jlbAboutTitle = new JLabel("About");
    private JButton jbtConfirmAbout = new JButton("Confirm");

    private JTextField jtfRename = new JTextField(" ");
    private JButton jbtConfirmRename = new JButton("Confirm");
    private JLabel jlbRenameTitle = new JLabel("Rename");



    private JLabel jlbSale1 = new JLabel();
    private JLabel jlbSale2 = new JLabel();
    private JLabel jlbSale3 = new JLabel();
    private JLabel jlbSale4 = new JLabel();
    private JLabel jlbSale5 = new JLabel();
    private JLabel jlbSale6 = new JLabel();
    private JLabel jlbSale7 = new JLabel();
    private JLabel jlbSale8 = new JLabel();
    private JLabel jlbSale9 = new JLabel();
    private JLabel jlbSale10 = new JLabel();



//    jpnCard


    public Shop11(JFrame jFrame){
        init(jFrame);
    }
    public void init(JFrame jFrame){
        this.setBounds(150,100,1600,850);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.map = jFrame;
        cp = this.getContentPane();
        cp.setLayout(null);
        cp.add(jpnC);
        cp.add(jpnN);
        cp.add(jpnSetting);
        cp.add(jpnAbout);
        cp.add(jpnRename);
        cp.add(jsp);
        cp.add(jpnCard2);
        cp.add(jpnCard);
        cp.add(jbtConfirmCard);
        cp.add(jpnShop);


//        jpnC
        jpnC.setBounds(0,75,1600,775);
        jpnC.setLayout(null);
        jpnC.add(jlbAshe);
        jpnC.add(jlbMonster);
        jpnC.add(jlbMonsterLabel);
        jpnC.add(jlbForest);

//        jpnN
        jpnN.setBounds(0,0,1600,75);
        jpnN.setBackground(new Color(61,73,78));
        jpnN.setLayout(null);

        jpnN.add(jlbName);
        jpnN.add(jlbRole);
        jpnN.add(heartImg);
        jpnN.add(jlbHeartInt);
        jpnN.add(moneyImg);
        jpnN.add(jlbMoneyInt);
        jpnN.add(mapImg);
        jpnN.add(settingImg);

        jlbMonsterLabel.setBounds(920,170,280,156);
        jlbMonsterLabel.setForeground(Color.WHITE);
        jlbMonsterLabel.setOpaque(true);
        jlbMonsterLabel.setFont(MyFont.WeiRuan40);
        jlbMonsterLabel.setBackground(Color.black);
        jlbMonsterLabel.setHorizontalAlignment(SwingConstants.CENTER);
        jlbMonsterLabel.setVerticalAlignment(SwingConstants.CENTER);
        jlbName.setBounds(10,7,nameLength,65);
        jlbName.setFont(MyFont.Antiqua65);
        jlbName.setForeground(Color.WHITE);
        jlbRole.setBounds(roleLength,23,150,40);
        jlbRole.setFont(MyFont.WeiRuan40);
        heartImg.setBounds(700,20,38,32);
        jlbHeartInt.setBounds(780,10,100,50);
        jlbHeartInt.setFont(MyFont.Antiqua50);
        jlbHeartInt.setForeground(Color.WHITE);
        moneyImg.setBounds(950,17,46,39);
        jlbMoneyInt.setBounds(1030,10,100,50);
        jlbMoneyInt.setFont(MyFont.Antiqua50);
        jlbMoneyInt.setForeground(Color.WHITE);
        mapImg.setBounds(1400,10,53,50);
        settingImg.setBounds(1500,10,53,52);

        jpnSetting.setBackground(new Color(165,191,199));
        jpnSetting.setBounds(600,100,400,550);
        jpnSetting.setLayout(null);
        jpnSetting.add(jbtAbout);
        jpnSetting.add(jbtRename);
        jpnSetting.add(jbtRetry);
        jpnSetting.add(jbtClose);
        jpnSetting.add(jbtConfirmSetting);
        jbtAbout.setBounds(100,50,200,70);
        jbtRename.setBounds(100,150,200,70);
        jbtRetry.setBounds(100,250,200,70);
        jbtClose.setBounds(100,350,200,70);
        jbtConfirmSetting.setBounds(150,470,100,50);
        jbtAbout.setBorder(BorderFactory.createRaisedBevelBorder());
        jbtRename.setBorder(BorderFactory.createRaisedBevelBorder());
        jbtRetry.setBorder(BorderFactory.createRaisedBevelBorder());
        jbtClose.setBorder(BorderFactory.createRaisedBevelBorder());
        jbtConfirmSetting.setBorder(BorderFactory.createRaisedBevelBorder());
        jpnSetting.setVisible(false);

        jpnAbout.setBackground(new Color(165,191,199));
        jpnAbout.setBounds(600,100,400,550);
        jpnAbout.setLayout(null);
        jpnAbout.add(jlbAbout);
        jpnAbout.add(jbtConfirmAbout);
        jpnAbout.add(jlbAboutTitle);
        jlbAboutTitle.setBounds(125,50,150,50);
        jlbAboutTitle.setFont(MyFont.Antiqua50);
        jlbAbout.setBounds(100,100,200,200);
        jbtConfirmAbout.setBounds(150,470,100,50);
        jpnAbout.setVisible(false);

        jpnRename.setBackground(new Color(165,191,199));
        jpnRename.setBounds(600,100,400,550);
        jpnRename.setLayout(null);
        jpnRename.add(jtfRename);
        jpnRename.add(jlbRenameTitle);
        jpnRename.add(jbtConfirmRename);
        jlbRenameTitle.setFont(MyFont.Antiqua50);
        jtfRename.setBounds(100,200,200,50);
        jlbRenameTitle.setBounds(100,50,200,50);
        jbtConfirmRename.setBounds(150,470,100,50);
        jpnRename.setVisible(false);

        jsp.setBounds(100,120,708,650);
        jsp.setVisible(false);
        Bar.setUnitIncrement(40);
        jspShop.setBounds(100,120,708,650);
        jspShop.setVisible(false);
        BarShop.setUnitIncrement(40);

        jpnCard.setBounds(0,0,708,1590);
        jpnCard.setPreferredSize(new Dimension(708,1590));
        jpnCard.setBackground(new Color(165,191,199));
        jpnCard.setVisible(false);
        jpnCard.setLayout(null);

        jpnCard2.setBounds(843,120,485,650);
        jpnCard2.setBackground(new Color(165,191,199));
        jpnCard2.setVisible(false);


        jpnCardShop.setBounds(0,0,708,1590);
        jpnCardShop.setPreferredSize(new Dimension(708,1590));
        jpnCardShop.setBackground(new Color(165,191,199));
        jpnCardShop.setVisible(false);
        jpnCardShop.setLayout(null);

        jpnCardShop2.setBounds(843,120,485,650);
        jpnCardShop2.setBackground(new Color(165,191,199));
        jpnCardShop2.setVisible(false);


//        jpnShop
        jpnShop.setLayout(null);
        jpnShop.setBounds(0, 50,1600,830);
        jpnShop.setBackground(new Color(165,191,199));
        jpnShop.setVisible(false);
        jpnShop.add(jlbSale1);
        jpnShop.add(jlbSale2);
        jpnShop.add(jlbSale3);
        jpnShop.add(jlbSale4);
        jpnShop.add(jlbSale5);
        jpnShop.add(jlbSale6);
        jpnShop.add(jlbSale7);
        jpnShop.add(jlbSale8);
        jpnShop.add(jlbSale9);
        jpnShop.add(jlbSale10);
        jlbSale1.setBounds(25,70,250,335);
        jlbSale2.setBounds(320,70,250,335);
        jlbSale3.setBounds(590,70,250,335);
        jlbSale4.setBounds(860,70,250,335);
        jlbSale5.setBounds(1130,70,250,335);
        jlbSale6.setBounds(25,410,250,335);
        jlbSale7.setBounds(320,410,250,335);
        jlbSale8.setBounds(590,410,250,335);
        jlbSale9.setBounds(860,410,250,335);
        jlbSale10.setBounds(1130,410,250,335);

//
        jlbAshe.setBounds(250,270,208,222);
        jlbMonster.setBounds(1030,330,226,156);

        jlbForest.setBounds(0,0,1600,850);

        jlbForest.setIcon(ImageManager.resize(ImageManager.iconForest, 1600,850,Image.SCALE_SMOOTH));
        jlbAshe.setIcon(ImageManager.resize(ImageManager.iconAshe, 208,222,Image.SCALE_SMOOTH));
        jlbMonster.setIcon(ImageManager.resize(ImageManager.iconGoldenPig, 63,59,Image.SCALE_SMOOTH));
        moneyImg.setIcon(ImageManager.resize(ImageManager.iconMoney, 46,39,Image.SCALE_SMOOTH));
        heartImg.setIcon(ImageManager.resize(ImageManager.iconHeart, 38,32,Image.SCALE_SMOOTH));
        mapImg.setIcon(ImageManager.resize(ImageManager.iconMap, 53,50,Image.SCALE_SMOOTH));
        settingImg.setIcon(ImageManager.resize(ImageManager.iconSetting, 53,52,Image.SCALE_SMOOTH));
        jlbSale1.setIcon(ImageManager.resize(ImageManager.iconCardAtk9, 250,335,Image.SCALE_SMOOTH));
        jlbSale2.setIcon(ImageManager.resize(ImageManager.iconCardAtk11, 250,335,Image.SCALE_SMOOTH));
        jlbSale3.setIcon(ImageManager.resize(ImageManager.iconCardAtk6, 250,335,Image.SCALE_SMOOTH));
        jlbSale4.setIcon(ImageManager.resize(ImageManager.iconCardAtk14, 250,335,Image.SCALE_SMOOTH));
        jlbSale5.setIcon(ImageManager.resize(ImageManager.iconCardAtk7, 250,335,Image.SCALE_SMOOTH));
        jlbSale6.setIcon(ImageManager.resize(ImageManager.iconCardAtk17, 250,335,Image.SCALE_SMOOTH));
        jlbSale7.setIcon(ImageManager.resize(ImageManager.iconCardAtk4, 250,335,Image.SCALE_SMOOTH));
        jlbSale8.setIcon(ImageManager.resize(ImageManager.iconCardAtk3, 250,335,Image.SCALE_SMOOTH));
        jlbSale9.setIcon(ImageManager.resize(ImageManager.iconCardHeal, 250,335,Image.SCALE_SMOOTH));
        jlbSale10.setIcon(ImageManager.resize(ImageManager.iconCardRecycle, 250,335,Image.SCALE_SMOOTH));


        jlbSale1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2){
                    if (moneyInt > 50){
                        Card card = new Card("刃雨",ImageManager.iconCardAtk9);
                        Map.VA.add(card);
                        moneyInt = moneyInt - 50;
                        jlbMoneyInt.setText(Integer.toString(moneyInt));
                        jlbSale1.setIcon(null);
                        Map.cardInt = Map.VA.size();
                        Map.jlbCardInt.setText(Integer.toString(Map.cardInt));
                    }else {
                        jlbMoneyInt.setText("金錢不足");
                    }
                }
            }
        });
        jlbSale2.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2){
                    if (moneyInt > 50){
                        Card card = new Card("精準的雞",ImageManager.iconCardAtk11);
                        Map.VA.add(card);
                        moneyInt = moneyInt - 50;
                        jlbMoneyInt.setText(Integer.toString(moneyInt));
                        jlbSale2.setIcon(null);
                        Map.cardInt = Map.VA.size();
                        Map.jlbCardInt.setText(Integer.toString(Map.cardInt));
                    }else {
                        jlbMoneyInt.setText("金錢不足");
                    }
                }
            }
        });
        jlbSale3.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2){
                    if (moneyInt > 50) {
                        Card card = new Card("音速箭", ImageManager.iconCardAtk6);
                        Map.VA.add(card);
                        moneyInt = moneyInt - 50;
                        jlbMoneyInt.setText(Integer.toString(moneyInt));
                        jlbSale3.setIcon(null);
                        Map.cardInt = Map.VA.size();
                        Map.jlbCardInt.setText(Integer.toString(Map.cardInt));
                    }else {
                        jlbMoneyInt.setText("金錢不足");
                    }
                }
            }
        });
        jlbSale4.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2){
                    if (moneyInt > 50){
                        Card card = new Card("自體爆破",ImageManager.iconCardAtk14);
                        Map.VA.add(card);
                        moneyInt = moneyInt - 50;
                        jlbMoneyInt.setText(Integer.toString(moneyInt));
                        jlbSale4.setIcon(null);
                        Map.cardInt = Map.VA.size();
                        Map.jlbCardInt.setText(Integer.toString(Map.cardInt));
                    }else {
                        jlbMoneyInt.setText("金錢不足");
                    }
                }
            }
        });
        jlbSale5.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2){
                    if (moneyInt > 50){
                        Card card = new Card("烏龜頭箭",ImageManager.iconCardAtk7);
                        Map.VA.add(card);
                        moneyInt = moneyInt - 50;
                        jlbMoneyInt.setText(Integer.toString(moneyInt));
                        jlbSale5.setIcon(null);
                        Map.cardInt = Map.VA.size();
                        Map.jlbCardInt.setText(Integer.toString(Map.cardInt));
                    }else {
                        jlbMoneyInt.setText("金錢不足");
                    }
                }
            }
        });
        jlbSale6.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2){
                    if (moneyInt > 50){
                        Card card = new Card("鳥鳥打擊",ImageManager.iconCardAtk17);
                        Map.VA.add(card);
                        moneyInt = moneyInt - 50;
                        jlbMoneyInt.setText(Integer.toString(moneyInt));
                        jlbSale6.setIcon(null);
                        Map.cardInt = Map.VA.size();
                        Map.jlbCardInt.setText(Integer.toString(Map.cardInt));
                    }else {
                        jlbMoneyInt.setText("金錢不足");
                    }
                }
            }
        });
        jlbSale7.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2){
                    if (moneyInt > 50){
                        Card card = new Card("聖盾射擊",ImageManager.iconCardAtk4);
                        Map.VA.add(card);
                        moneyInt = moneyInt - 50;
                        jlbMoneyInt.setText(Integer.toString(moneyInt));
                        jlbSale7.setIcon(null);
                        Map.cardInt = Map.VA.size();
                        Map.jlbCardInt.setText(Integer.toString(Map.cardInt));
                    }else {
                        jlbMoneyInt.setText("金錢不足");
                    }
                }
            }
        });
        jlbSale8.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2){
                    if (moneyInt > 50) {
                        Card card = new Card("光明箭矢", ImageManager.iconCardAtk3);
                        Map.VA.add(card);
                        moneyInt = moneyInt - 50;
                        jlbMoneyInt.setText(Integer.toString(moneyInt));
                        jlbSale8.setIcon(null);
                        Map.cardInt = Map.VA.size();
                        Map.jlbCardInt.setText(Integer.toString(Map.cardInt));
                    }else {
                        jlbMoneyInt.setText("金錢不足");
                    }
                }
            }
        });
        jlbSale9.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2){
                    if (moneyInt > 50) {
                        jlbSale9.setIcon(null);
                        moneyInt = moneyInt - 50;
                        jlbMoneyInt.setText(Integer.toString(moneyInt));
                        heartInt += 20;
                        jlbHeartInt.setText(Integer.toString(heartInt));
                        Map.cardInt = Map.VA.size();
                        Map.jlbCardInt.setText(Integer.toString(Map.cardInt));
                    }else {
                        jlbMoneyInt.setText("金錢不足");
                    }
                }
            }
        });


        jlbMonster.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                jlbMonsterTalk.setVisible(true);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                jlbMonsterTalk.setVisible(false);
            } @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                jpnShop.setVisible(true);
                jpnC.setVisible(false);
            }
        });
        jlbSale10.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2){
                    Map.moneyInt = moneyInt;
                    Map.jlbMoneyInt.setText(Integer.toString(Map.moneyInt));
                    Map.cardInt = Map.VA.size();
                    Map.jlbCardInt.setText(Integer.toString(Map.cardInt));
                    map.setExtendedState(JFrame.NORMAL);
                    Shop11.this.setVisible(false);

                }

            }
        });
        mapImg.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                Map2 mp2 = new Map2();
                mp2.setVisible(true);
            }
        });
        settingImg.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                jpnSetting.setVisible(true);
                jpnC.setVisible(false);
            }
        });
        jbtAbout.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jpnAbout.setVisible(true);
                jpnSetting.setVisible(false);

            }
        });

        jbtConfirmCard.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jsp.setVisible(false);
                jpnCard2.setVisible(false);
                jpnC.setVisible(true);
                jbtConfirmCard.setVisible(false);
            }
        });
    }
}













