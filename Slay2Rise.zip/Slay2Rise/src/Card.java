import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;

public class Card{
    ImageIcon imageIcon;
    JLabel jlbMapCard = new JLabel();
    JLabel jlbGameCard = new JLabel();
    String cardName;
    CardInteraction battle;
    Random rdm1 = new Random();


    Card (String cardName, ImageIcon imageIcon){
        this.imageIcon = imageIcon;
        this.cardName = cardName;
        this.imageIcon.setImage(imageIcon.getImage().getScaledInstance(485, 650, Image.SCALE_SMOOTH));
        jlbMapCard.setIcon(ImageManager.resize(imageIcon,157,210, Image.SCALE_SMOOTH));
        jlbGameCard.setIcon(ImageManager.resize(imageIcon,157,210, Image.SCALE_SMOOTH));


        jlbMapCard.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (cardName.equals("射擊!")){
                    Map.jlbCardBig.setIcon(ImageManager.iconCardAtk1);
                }
                if (cardName.equals("光明射擊")){
                    Map.jlbCardBig.setIcon(ImageManager.iconCardAtk2);
                }
                if (cardName.equals("光明箭矢")){
                    Map.jlbCardBig.setIcon(ImageManager.iconCardAtk3);
                }
                if (cardName.equals("聖盾射擊")){
                    Map.jlbCardBig.setIcon(ImageManager.iconCardAtk4);
                }
                if (cardName.equals("藍色牛角麵包")){
                    Map.jlbCardBig.setIcon(ImageManager.iconCardAtk5);
                }
                if (cardName.equals("音速箭")){
                    Map.jlbCardBig.setIcon(ImageManager.iconCardAtk6);
                }
                if (cardName.equals("烏龜頭箭")){
                    Map.jlbCardBig.setIcon(ImageManager.iconCardAtk7);
                }
                if (cardName.equals("鐮刀小鬼")){
                    Map.jlbCardBig.setIcon(ImageManager.iconCardAtk8);
                }
                if (cardName.equals("刃雨")){
                    Map.jlbCardBig.setIcon(ImageManager.iconCardAtk9);
                }
                if (cardName.equals("捨命箭雨")){
                    Map.jlbCardBig.setIcon(ImageManager.iconCardAtk10);
                }
                if (cardName.equals("精準的雞")){
                    Map.jlbCardBig.setIcon(ImageManager.iconCardAtk11);
                }
                if (cardName.equals("牙籤之舞")){
                    Map.jlbCardBig.setIcon(ImageManager.iconCardAtk12);
                }
                if (cardName.equals("感染")){
                    Map.jlbCardBig.setIcon(ImageManager.iconCardAtk13);
                }
                if (cardName.equals("自體爆破")){
                    Map.jlbCardBig.setIcon(ImageManager.iconCardAtk14);
                }
                if (cardName.equals("詛咒")){
                    Map.jlbCardBig.setIcon(ImageManager.iconCardAtk15);
                }
                if (cardName.equals("BANG!")){
                    Map.jlbCardBig.setIcon(ImageManager.iconCardAtk16);
                }
                if (cardName.equals("鳥鳥打擊")){
                    Map.jlbCardBig.setIcon(ImageManager.iconCardAtk17);
                }
                if (cardName.equals("命運之輪")){
                    Map.jlbCardBig.setIcon(ImageManager.iconCardAtk18);
                }
                if (cardName.equals("守護!")){
                    Map.jlbCardBig.setIcon(ImageManager.iconCardShield1);
                }
                if (cardName.equals("神聖之盾")){
                    Map.jlbCardBig.setIcon(ImageManager.iconCardShield2);
                }
                if (cardName.equals("捨棄之盾")){
                    Map.jlbCardBig.setIcon(ImageManager.iconCardShield3);
                }
                if (cardName.equals("天使祝福")){
                    Map.jlbCardBig.setIcon(ImageManager.iconCardShield4);
                }
                if (cardName.equals("齒輪長翅膀")){
                    Map.jlbCardBig.setIcon(ImageManager.iconCardShield5);
                }
                if (cardName.equals("禁咒")){
                    Map.jlbCardBig.setIcon(ImageManager.iconCardBuff1);
                }
                if (cardName.equals("未知的力量")){
                    Map.jlbCardBig.setIcon(ImageManager.iconCardBuff2);
                }
                if (cardName.equals("激發")){
                    Map.jlbCardBig.setIcon(ImageManager.iconCardBuff3);
                }
                if (cardName.equals("湖中女神")){
                    Map.jlbCardBig.setIcon(ImageManager.iconCardBuff4);
                }
                if (cardName.equals("好亮喔~~")){
                    Map.jlbCardBig.setIcon(ImageManager.iconCardBuff5);
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                Map.jlbCardBig.setIcon(null);
            }
        });
        if (cardName.equals("射擊!")){
            jlbGameCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2 && battle.getEnergy() - 1 >= 0){
                        battle.playGif(cardName, 910);
                        battle.putCard2Dis(Card.this);
                        battle.useEnergy(1);
                        battle.attack(rdm1.nextInt(5) + 6);
                    }else if(battle.getEnergy() - 1 < 0){
                        battle.setWarning("能量不足!");
                    }
                }
            });
        }else if (cardName.equals("守護!")){
            jlbGameCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2 && battle.getEnergy() - 1 >= 0){
                        battle.playGif(cardName, 1000);
                        battle.useEnergy(1);
                        battle.addShield(6);
                        battle.putCard2Dis(Card.this);
                    } else if(battle.getEnergy() - 1 < 0){
                        battle.setWarning("能量不足!");
                    }

                }
            });
        }else  if (cardName.equals("光明射擊")){
            jlbGameCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2 && battle.getEnergy() - 2 >= 0){
                        battle.playGif(cardName,1700);
                        battle.useEnergy(2);
                        battle.attack(rdm1.nextInt(6) + 10);
                        battle.addStatus("weak", 2);
                        battle.putCard2Dis(Card.this);
                    }else if(battle.getEnergy() - 2 < 0){
                        battle.setWarning("能量不足!");
                    }

                }
            });
        }else  if (cardName.equals("光明箭矢")){
            jlbGameCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2 && battle.getEnergy() - 1 >= 0){
                        battle.playGif(cardName,1270);
                        battle.useEnergy(1);
                        battle.attack(rdm1.nextInt(5) + 8);
                        battle.drawCard(1);
                        battle.putCard2Dis(Card.this);
                    }else if(battle.getEnergy() - 1 < 0){
                        battle.setWarning("能量不足!");
                    }

                }
            });
        }else  if (cardName.equals("聖盾射擊")){
            jlbGameCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2 && battle.getEnergy() - 1 >= 0){
                        battle.playGif(cardName,820);
                        battle.useEnergy(1);
                        battle.attack(battle.getShield());
                        battle.putCard2Dis(Card.this);
                    }else if(battle.getEnergy() - 1 < 0){
                        battle.setWarning("能量不足!");
                    }

                }
            });
        }else  if (cardName.equals("藍色牛角麵包")){
            jlbGameCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2 && battle.getEnergy() - 1 >= 0){
                        battle.playGif(cardName,1020);
                        battle.useEnergy(1);
                        battle.attack(8);
                        battle.addShield(7);
                        battle.putCard2Dis(Card.this);
                    }else if(battle.getEnergy() - 1 < 0){
                        battle.setWarning("能量不足!");
                    }

                }
            });
        }else  if (cardName.equals("音速箭")){
            jlbGameCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2 ){
                        battle.playGif(cardName,260);
                        battle.useEnergy(0);
                        battle.attack(5);

                       while(1 == 1){
                           int i = rdm1.nextInt(2);
                           if (i == 0){
                               battle.attack(5);
                           }else {
                               break;
                           }
                       }
                        battle.putCard2Dis(Card.this);
                    }

                }
            });
        }else  if (cardName.equals("烏龜頭箭")){
            jlbGameCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2 && battle.getEnergy() - 1 >= 0){
                        battle.playGif(cardName,1450);
                        battle.useEnergy(1);
                        int a = rdm1.nextInt(2);
                        int b = 0;
                        switch (a){
                            case 0 : b += 8;
                            case 1 : b += 16;
                        }
                        battle.attack(b);
                        battle.addStatus("weak", 1);
                        battle.putCard2Dis(Card.this);
                    }else if(battle.getEnergy() - 1 < 0){
                        battle.setWarning("能量不足!");
                    }

                }
            });
        }else  if (cardName.equals("鐮刀小鬼")){
            jlbGameCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2 && battle.getEnergy() - 1 >= 0){
                        battle.playGif(cardName,900);
                        battle.useEnergy(1);
                        battle.attack(10);
                        battle.putCard2Dis(Card.this);
                    }else if(battle.getEnergy() - 1 < 0){
                        battle.setWarning("能量不足!");
                    }

                }
            });
        }else  if (cardName.equals("刃雨")){
            jlbGameCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2 && battle.getEnergy() - 1 >= 0){
                        battle.playGif(cardName,810);
                        battle.useEnergy(1);
                        battle.attack(15);
                        battle.putCard2Dis(Card.this);
                    }else if(battle.getEnergy() - 1 < 0){
                        battle.setWarning("能量不足!");
                    }

                }
            });
        }else  if (cardName.equals("捨命箭雨")){
            jlbGameCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2 && battle.getEnergy() - 1 >= 0){
                        battle.playGif(cardName,1100 * battle.getEnergy());
                        battle.useEnergy(battle.getEnergy());
                        battle.attack(10 * battle.getEnergy());
                        battle.putCard2Dis(Card.this);
                    }else if(battle.getEnergy() - 1 < 0){
                        battle.setWarning("能量不足!");
                    }

                }
            });
        }else  if (cardName.equals("精準的雞")){
            jlbGameCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2 && battle.getEnergy() - 2 >= 0){
                        battle.playGif(cardName,1000);
                        battle.useEnergy(2);
                        battle.addStatus("weak",  3);
                        battle.addStatus("hurt",  3);
                        battle.putCard2Dis(Card.this);
                    }else if(battle.getEnergy() - 2 < 0){
                        battle.setWarning("能量不足!");
                    }

                }
            });
        }else  if (cardName.equals("牙籤之舞")){
            jlbGameCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2 && battle.getEnergy() - 1 >= 0){
                        battle.playGif(cardName,1110);
                        battle.useEnergy(1);
                        battle.attack(8);
                        battle.addStatus("weak", 1);
                        battle.putCard2Dis(Card.this);
                    }else if(battle.getEnergy() - 1 < 0){
                        battle.setWarning("能量不足!");
                    }

                }
            });
        }else  if (cardName.equals("感染")){
            jlbGameCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2 && battle.getEnergy() - 1 >= 0){
                        battle.playGif(cardName,1000);
                        battle.useEnergy(1);
                        battle.attack(rdm1.nextInt(7) + 2);
                        battle.attack(rdm1.nextInt(7) + 2);
                        battle.attack(rdm1.nextInt(7) + 2);
                        battle.putCard2Dis(Card.this);
                    }else if(battle.getEnergy() - 2 < 0){
                        battle.setWarning("能量不足!");
                    }

                }
            });
        }else  if (cardName.equals("自體爆破")){
            jlbGameCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2 && battle.getEnergy() - 1 >= 0){
                        battle.playGif(cardName,1080);
                        battle.useEnergy(1);
                        battle.attack(20);
                        battle.putCard2Dis(Card.this);
                        Card card = new Card("傷口",ImageManager.iconCardInjure);
                        Map.VA.add(card);
                    }else if(battle.getEnergy() - 1 < 0){
                        battle.setWarning("能量不足!");
                    }

                }
            });
        }else  if (cardName.equals("詛咒")){
            jlbGameCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2 && battle.getEnergy() - 1 >= 0){
                        battle.playGif(cardName,1300);
                        battle.useEnergy(1);
                        battle.attack(18);
                        battle.heal(-3);
                        battle.putCard2Dis(Card.this);
                    }else if(battle.getEnergy() - 1 < 0){
                        battle.setWarning("能量不足!");
                    }

                }
            });
        }else  if (cardName.equals("BANG!")){
            jlbGameCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2 && battle.getEnergy() - 3 >= 0){
                        battle.playGif(cardName,1780);
                        battle.useEnergy(3);
                        battle.attack(50);
                        battle.putCard2Dis(Card.this);
                    }else if(battle.getEnergy() - 3 < 0){
                        battle.setWarning("能量不足!");
                    }

                }
            });
        }else  if (cardName.equals("鳥鳥打擊")){
            jlbGameCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2 && battle.getEnergy() - 1 >= 0){
                        battle.playGif(cardName,1000);
                        battle.useEnergy(1);
                        battle.attack(5);
                        battle.addStatus("weak", 1);
                        battle.putCard2Dis(Card.this);
                    }else if(battle.getEnergy() - 1 < 0){
                        battle.setWarning("能量不足!");
                    }

                }
            });
        }else  if (cardName.equals("命運之輪")){
            jlbGameCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2 && battle.getEnergy() - 1 >= 0){
                        battle.playGif(cardName,1440);
                        battle.useEnergy(1);
                        int i = rdm1.nextInt(2);
                        if (i == 0) {
                            battle.attack(35);
                        }else {
                            battle.attack(-15);
                        }
                        battle.putCard2Dis(Card.this);
                    }else if(battle.getEnergy() - 1 < 0){
                        battle.setWarning("能量不足!");
                    }

                }
            });
        }else  if (cardName.equals("禁咒")){
            jlbGameCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2 ){
                        battle.playGif(cardName,1320);
                        battle.useEnergy(0);
                        battle.heal(-3);
                        battle.useEnergy(-1);
                        battle.putCard2Dis(Card.this);
                    }

                }
            });
        }else  if (cardName.equals("未知的力量")){
            jlbGameCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2){
                        battle.playGif(cardName,1320);
                        battle.useEnergy(0);
                        battle.addStatus("str", 1);
                        battle.putCard2Dis(Card.this);
                    }

                }
            });
        }else  if (cardName.equals("激發")){
            jlbGameCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2 && battle.getEnergy() - 1 >= 0){
                        battle.playGif(cardName,720);
                        battle.useEnergy(1);
                        battle.useEnergy(-2);
                        battle.drawCard(1);
                        battle.addStatus("AsheWeak", 2);
                        battle.putCard2Dis(Card.this);
                    }else if(battle.getEnergy() - 1 < 0){
                        battle.setWarning("能量不足!");
                    }

                }
            });
        }else  if (cardName.equals("湖中女神")){
            jlbGameCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2){
                        battle.playGif(cardName,1440);
                        battle.drawCard(3);
                        battle.putCard2Dis(Card.this);
                    }else if(battle.getEnergy() - 2 < 0){
                        battle.setWarning("能量不足!");
                    }

                }
            });
        }else  if (cardName.equals("好亮喔~~")){
            jlbGameCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2 && battle.getEnergy() - 3 >= 0){
                        battle.playGif(cardName,800);
                        battle.useEnergy(3);
                        battle.useEnergy(-1);
                        int j = rdm1.nextInt(3);
                        if (j == 0){
                            battle.attack(1000);
                        }else {
                            battle.attack(1);
                        }

                        battle.putCard2Dis(Card.this);
                    }else if(battle.getEnergy() - 3 < 0){
                        battle.setWarning("能量不足!");
                    }

                }
            });

        }else  if (cardName.equals("神聖之盾")){
            jlbGameCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2 && battle.getEnergy() - 1 >= 0){
                        battle.playGif(cardName,1530);
                        battle.useEnergy(1);
                        battle.addShield(10);
                        battle.drawCard(1);
                        battle.putCard2Dis(Card.this);
                    }else if(battle.getEnergy() - 1 < 0){
                        battle.setWarning("能量不足!");
                    }

                }
            });
        }else  if (cardName.equals("捨棄之盾")){
            jlbGameCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2 && battle.getEnergy() - 1 >= 0){
                        battle.playGif(cardName,1440);
                        battle.useEnergy(1);
                        battle.addShield(16);
                        battle.putCard2Dis(Card.this);
                    }else if(battle.getEnergy() - 1 < 0){
                        battle.setWarning("能量不足!");
                    }

                }
            });
        }else  if (cardName.equals("天使祝福")){
            jlbGameCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2 && battle.getEnergy() - 2 >= 0){
                        battle.playGif(cardName,1200);
                        battle.useEnergy(2);
                        battle.addShield(30);
                        battle.putCard2Dis(Card.this);
                    }else if(battle.getEnergy() - 2 < 0){
                        battle.setWarning("能量不足!");
                    }

                }
            });
        }else  if (cardName.equals("齒輪長翅膀")){
            jlbGameCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2 && battle.getEnergy() - 1 >= 0){
                        battle.playGif(cardName,1620);
                        battle.useEnergy(1);
                        battle.addShield(battle.getShield());
                        battle.putCard2Dis(Card.this);
                    }else if(battle.getEnergy() - 1 < 0){
                        battle.setWarning("能量不足!");
                    }

                }
            });
        }


    }
    public void setEnemy(CardInteraction enemy){
        this.battle = enemy;
    }
}
