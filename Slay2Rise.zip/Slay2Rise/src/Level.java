import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;


public abstract class Level extends JFrame implements CardInteraction{

    public JFrame map;     // 地圖的視窗
    public JLabel background = new JLabel();   // 最底層
//    排組
    public ArrayList<Card> deck = new ArrayList<>();
    public ArrayList<Card> hand = new ArrayList<>();
    public ArrayList<Card> dis = new ArrayList<>();

//    原本的 jpn
    public JPanel jpnHand = new JPanel();  // 手牌
    public JPanel jpnInfo = new JPanel();  // 包括 -> 能量 訊息 牌堆數量
    public JPanel jpnWin = new JPanel();    // 獲勝
    public JPanel jpnC = new JPanel();     // 人物 敵人 endBtn 都放在這

//    很多的 jlb jlb
    public JButton jbtEnd = new JButton("End");     //
    private JLabel jlbMeet = new JLabel("發現敵人!");
    public JLabel jlbRound = new JLabel("你的回合");
    public JLabel jlbLose = new JLabel("失敗");
    public JLabel jlbWin = new JLabel("勝利!");
    public JLabel jlbPower = new JLabel();
    public JLabel jlbTurn = new JLabel("你的回合"); // 設定順序
    public JLabel jlbCard = new JLabel();
    public JLabel jlbDeck = new JLabel();               //
    public JLabel jlbDis = new JLabel();                //
    private JLabel jlbJiangLi = new JLabel("獎勵!");
    private JLabel jlbMoneyImg = new JLabel();
    public JLabel jlbGetMoney = new JLabel("0");
    public JLabel jlbChoose1 = new JLabel();
    public JLabel jlbChoose2 = new JLabel();
    public JLabel jlbChoose3 = new JLabel();

//    player
    public JLabel jlbAshe = new JLabel();
    public JLabel jlbAsheWeak = new JLabel();
    public JLabel jlbAsheHurt = new JLabel();
    public JLabel jlbAsheStr = new JLabel();
    public JLabel jlbAsheHp = new JLabel();
    public JLabel jlbAsheHpChange = new JLabel();
    public JLabel jlbAsheShield = new JLabel();
    public JLabel AsheGif = new JLabel();

//    Monster
    public JLabel jlbMonster = new JLabel();
    public JLabel jlbMonsterWeak = new JLabel();
    public JLabel jlbMonsterHurt = new JLabel();
    public JLabel jlbMonsterStr = new JLabel();
    public JLabel jlbMonsterAtk = new JLabel();
    public JLabel jlbMonsterHp = new JLabel();
    public JLabel jlbMonsterHpChange = new JLabel();

//    other
    public Random rdm1 = new Random();

    public Level (JFrame jFrame){
        init(jFrame);
    }

    private void init(JFrame jFrame) {
        this.map = jFrame;
//        視窗基本設定
        this.setBounds(150, 100, 1600, 850);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        background.setIcon(ImageManager.resize(ImageManager.iconForest, 1600, 850, Image.SCALE_SMOOTH));
        this.add(background);    // 設置背景圖 所有的JPanel都加到這上面

//        add 一大堆東西 愈早add的元件 會愈上層
        background.add(jpnWin);
        background.add(jlbLose);
        background.add(jlbWin);
        background.add(jlbMeet);
        background.add(jlbRound);
        background.add(jpnInfo);
        background.add(jpnHand);
        background.add(jpnC);
        background.add(jbtEnd);

        jpnInfo.add(jlbPower);
        jpnInfo.add(jlbTurn);
        jpnInfo.add(jlbCard);
        jpnInfo.add(jlbDeck);
        jpnInfo.add(jlbDis);

        jpnWin.add(jlbJiangLi);
        jpnWin.add(jlbMoneyImg);
        jpnWin.add(jlbGetMoney);
        jpnWin.add(jlbChoose1);
        jpnWin.add(jlbChoose2);
        jpnWin.add(jlbChoose3);

        jpnC.add(jlbAshe);
        jpnC.add(jlbMonster);
        jpnC.add(jlbAsheHp);
        jpnC.add(jlbMonsterHp);
        jpnC.add(jlbAsheHpChange);
        jpnC.add(jlbMonsterHpChange);
        jpnC.add(jlbAsheWeak);
        jpnC.add(jlbAsheHurt);
        jpnC.add(jlbAsheStr);
        jpnC.add(jlbMonsterWeak);
        jpnC.add(jlbMonsterHurt);
        jpnC.add(jlbMonsterStr);
        jpnC.add(jlbAsheShield);
        jpnC.add(jlbMonsterAtk);
        jpnC.add(AsheGif);

//        卡牌設定
        deck.addAll(Map.VA);
        for (int i = 0; i < Map.VA.size(); i++){
            deck.get(i).setEnemy(this);
        }
        drawCard();
        drawCard();
        drawCard();
        drawCard();
        drawCard();

//        win
        jpnWin.setBounds(400,100,800,600);
        jpnWin.setBackground(new Color(165,191,199));
        jpnWin.setLayout(null);
        jpnWin.setVisible(false);
//        jiangLi
        jlbJiangLi.setBounds(310,10,250,80);
        jlbMoneyImg.setBounds(340,170,46,39);
        jlbGetMoney.setBounds(410,150,100,70);
        jlbChoose1.setBounds(30,230,242,325);
        jlbChoose2.setBounds(282,230,242,325);
        jlbChoose3.setBounds(534,230,242,325);
        jlbJiangLi.setFont(MyFont.WeiRuan80);
        jlbGetMoney.setFont(MyFont.WeiRuan50);
        jlbMoneyImg.setIcon(ImageManager.resize(ImageManager.iconMoney, 46,39, Image.SCALE_SMOOTH));
        jlbChoose1.setIcon(null);
        jlbChoose2.setIcon(null);
        jlbChoose3.setIcon(null);
//        lose
        jlbLose.setBounds(0,0,1600,850);
        jlbLose.setFont(MyFont.WeiRuan600);
        jlbLose.setHorizontalAlignment(SwingConstants.CENTER);
        jlbLose.setVerticalAlignment(SwingConstants.CENTER);
        jlbLose.setOpaque(true);
        jlbLose.setForeground(Color.RED);
        jlbLose.setBackground(Color.black);
        jlbLose.setVisible(false);
        jlbWin.setBounds(0,0,1600,850);
        jlbWin.setFont(MyFont.WeiRuan600);
        jlbWin.setHorizontalAlignment(SwingConstants.CENTER);
        jlbWin.setVerticalAlignment(SwingConstants.CENTER);
        jlbWin.setOpaque(true);
        jlbWin.setForeground(Color.RED);
        jlbWin.setBackground(Color.black);
        jlbWin.setVisible(false);
//        meet
        jlbMeet.setBounds(0,200,1600,140);
        jlbMeet.setHorizontalAlignment(SwingConstants.CENTER);
        jlbMeet.setVerticalAlignment(SwingConstants.CENTER);
        jlbMeet.setFont(MyFont.WeiRuan80);
        jlbMeet.setOpaque(true);
        jlbMeet.setForeground(Color.WHITE);
        jlbMeet.setBackground(Color.black);
        jlbMeet.setVisible(false);
//        round
        jlbRound.setBounds(0,200,1600,140);
        jlbRound.setHorizontalAlignment(SwingConstants.CENTER);
        jlbRound.setVerticalAlignment(SwingConstants.CENTER);
        jlbRound.setFont(MyFont.WeiRuan80);
        jlbRound.setOpaque(true);
        jlbRound.setForeground(Color.WHITE);
        jlbRound.setBackground(Color.black);
        jlbRound.setVisible(false);
//        jpnHand
        jpnHand.setBounds(0,570,1600,220);
        jpnHand.setBackground(Color.black);
        jpnHand.setLayout(new FlowLayout(FlowLayout.CENTER,1,1));
        jpnHand.setVisible(false);
//        jpnInfo
        jpnInfo.setBounds(0, 20, 1600, 100);
        jpnInfo.setBackground(Color.WHITE);
        jpnInfo.setLayout(null);
        jpnInfo.setOpaque(false);
        jpnInfo.setVisible(false);
//        power
        jlbPower.setBounds(50, 0, 80, 70);
        jlbPower.setOpaque(true);
        jlbPower.setFont(MyFont.Antiqua65);
        jlbPower.setBackground(Color.BLACK);
        jlbPower.setForeground(Color.PINK);
        jlbPower.setHorizontalAlignment(SwingConstants.CENTER);
//        message
        jlbTurn.setBounds(600, 0, 400, 80);
        jlbTurn.setBackground(Color.BLACK);
        jlbTurn.setOpaque(true);
        jlbTurn.setFont(MyFont.WeiRuan50);
        jlbTurn.setForeground(Color.white);
        jlbTurn.setHorizontalAlignment(SwingConstants.CENTER);
//        deck & dis
        jlbCard.setBounds(1300, 0,80,70);
        jlbCard.setIcon(ImageManager.resize(ImageManager.iconCard, 70,70,Image.SCALE_SMOOTH));
        jlbDeck.setBounds(1400, 0, 80, 70);
        jlbDeck.setBackground(Color.BLACK);
        jlbDeck.setOpaque(true);
        jlbDeck.setFont(MyFont.Antiqua65);
        jlbDeck.setForeground(Color.PINK);
        jlbDeck.setHorizontalAlignment(SwingConstants.CENTER);
        jlbDis.setBounds(1500, 0, 80, 70);
        jlbDis.setBackground(Color.BLACK);
        jlbDis.setOpaque(true);
        jlbDis.setFont(MyFont.Antiqua65);
        jlbDis.setForeground(Color.PINK);
        jlbDis.setHorizontalAlignment(SwingConstants.CENTER);
//        endBtn
        jbtEnd.setBounds(1400, 475, 150, 70);
        jbtEnd.setBackground(Color.BLACK);
        jbtEnd.setForeground(Color.WHITE);
        jbtEnd.setFont(MyFont.Antiqua40);
        jbtEnd.setFocusPainted(false);
        jbtEnd.setVisible(false);
//        jpnC
        jpnC.setBounds(0, 0, 1600, 850);
        jpnC.setLayout(null);
        jpnC.setOpaque(false);
        jpnC.setVisible(false);
//        player
        jlbAshe.setBounds(250,270,208,222);

        jlbAsheHp.setBounds(275,180,100,70);
        jlbAsheHp.setBackground(new Color(0,0,0));
        jlbAsheHp.setOpaque(true);
        jlbAsheHp.setFont(MyFont.Antiqua65);
        jlbAsheHp.setForeground(Color.GREEN);
        jlbAsheHp.setHorizontalAlignment(SwingConstants.CENTER);

        jlbAsheHpChange.setBounds(285,110,100,70);
        jlbAsheHpChange.setFont(MyFont.Antiqua65);
        jlbAsheHpChange.setForeground(Color.RED);
        jlbAsheHpChange.setHorizontalAlignment(SwingConstants.CENTER);
        jlbAsheHpChange.setVisible(false);

        jlbAsheShield.setBounds(400,180,100,70);
        jlbAsheShield.setFont(MyFont.Antiqua65);
        jlbAsheShield.setForeground(Color.CYAN);
        jlbAsheShield.setHorizontalAlignment(SwingConstants.CENTER);

        jlbAsheWeak.setBounds(275,513,32,32);
        jlbAsheWeak.setVisible(false);

        jlbAsheHurt.setBounds(307,513,32,32);
        jlbAsheHurt.setVisible(false);

        jlbAsheStr.setBounds(339,513,32,32);
        jlbAsheStr.setVisible(false);

        jlbAshe.setIcon(ImageManager.resize(ImageManager.iconAshe, 208,222,Image.SCALE_SMOOTH));
        jlbAsheWeak.setIcon(ImageManager.resize(ImageManager.iconWeak, 32,32,Image.SCALE_SMOOTH));
        jlbAsheHurt.setIcon(ImageManager.resize(ImageManager.iconHurt, 32,32,Image.SCALE_SMOOTH));
        jlbAsheStr.setIcon(ImageManager.resize(ImageManager.iconStr, 1600,850,Image.SCALE_SMOOTH));
//        monster
        jlbMonster.setBounds(1000,270,238,220);

        jlbMonsterHp.setBounds(1050,180,100,70);
        jlbMonsterHp.setBackground(new Color(0,0,0));
        jlbMonsterHp.setOpaque(true);
        jlbMonsterHp.setFont(MyFont.Antiqua65);
        jlbMonsterHp.setForeground(Color.RED);
        jlbMonsterHp.setHorizontalAlignment(SwingConstants.CENTER);

        jlbMonsterHpChange.setBounds(1060,110,110,70);
        jlbMonsterHpChange.setFont(MyFont.Antiqua65);
        jlbMonsterHpChange.setForeground(Color.RED);
        jlbMonsterHpChange.setHorizontalAlignment(SwingConstants.CENTER);
        jlbMonsterHpChange.setVisible(false);

        jlbMonsterAtk.setBounds(1300,220,250,220);
        jlbMonsterAtk.setForeground(Color.RED);
        jlbMonsterAtk.setHorizontalAlignment(SwingConstants.CENTER);
        jlbMonsterAtk.setBackground(new Color(0,0,0));
        jlbMonsterAtk.setFont(MyFont.WeiRuan20);
        jlbMonsterAtk.setOpaque(true);
        jlbMonsterAtk.setVisible(false);

        jlbMonsterWeak.setBounds(1070,513,32,32);
        jlbMonsterWeak.setVisible(false);
        jlbMonsterWeak.setIcon(ImageManager.resize(ImageManager.iconWeak, 32,32,Image.SCALE_SMOOTH));

        jlbMonsterHurt.setBounds(1102,513,32,32);
        jlbMonsterHurt.setVisible(false);
        jlbMonsterHurt.setIcon(ImageManager.resize(ImageManager.iconHurt, 32,32,Image.SCALE_SMOOTH));

        jlbMonsterStr.setBounds(1134,513,32,32);
        jlbMonsterStr.setVisible(false);
        jlbMonsterStr.setIcon(ImageManager.resize(ImageManager.iconStr, 32,32,Image.SCALE_SMOOTH));

//        視窗一開始
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(WindowEvent e) {
                jlbMeet.setVisible(true);
                Timer timer = new Timer();
                timer.schedule(new TimerTask() {
                    @Override
                    public void run() {
                        jlbMeet.setVisible(false);
                        jlbRound.setVisible(true);
                    }
                }, 1000);
                timer.schedule(new TimerTask() {
                    @Override
                    public void run() {
                        jlbRound.setVisible(false);
                        jpnHand.setVisible(true);
                        jpnInfo.setVisible(true);
                        jbtEnd.setVisible(true);
                        jpnC.setVisible(true);
                    }
                }, 2000);
            }
        });
    }

    public void drawCard() {
        if (deck.size() == 0){
            while (dis.size() != 0){
                deck.add(dis.remove(0));
            }
        }
        int randomCard = rdm1.nextInt(deck.size());
        Card card = deck.remove(randomCard);

        hand.add(card);
        jpnHand.add(card.jlbGameCard);
        repaint();

        jlbDeck.setText(Integer.toString(deck.size()));
        jlbDis.setText(Integer.toString(dis.size()));
    }
}
