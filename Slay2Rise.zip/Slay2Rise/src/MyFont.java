import java.awt.*;

public class MyFont {
    public static Font Antiqua30 = new Font("Book Antiqua", Font.BOLD,30);
    public static Font Antiqua40 = new Font("Book Antiqua", Font.BOLD,40);
    public static Font Antiqua50 = new Font("Book Antiqua", Font.BOLD,50);
    public static Font Antiqua65 = new Font("Book Antiqua", Font.BOLD,65);

    public static Font WeiRuan20 = new Font("微軟正黑體", Font.BOLD,20);
    public static Font WeiRuan40 = new Font("微軟正黑體", Font.BOLD,40);
    public static Font WeiRuan50 = new Font("微軟正黑體", Font.BOLD,50);
    public static Font WeiRuan60 = new Font("微軟正黑體", Font.BOLD,60);
    public static Font WeiRuan80 = new Font("微軟正黑體", Font.BOLD,80);
    public static Font WeiRuan600 = new Font("微軟正黑體", Font.BOLD,600);
}
