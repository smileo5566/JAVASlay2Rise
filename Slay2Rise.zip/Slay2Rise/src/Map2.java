

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class Map2 extends JFrame{
    private Container cp;
    private JButton jbtClose = new JButton("Confirm");

    private JLabel jlbStage1 = new JLabel();
    private JLabel jlbStage2 = new JLabel();
    private JLabel jlbStage3 = new JLabel();
    private JLabel jlbStage4 = new JLabel();
    private JLabel jlbStage5 = new JLabel();
    private JLabel jlbStage6 = new JLabel();
    private JLabel jlbStage7 = new JLabel();
    private JLabel jlbStage8 = new JLabel();
    private JLabel jlbStage9 = new JLabel();
    private JLabel jlbStage10 = new JLabel();
    private JLabel jlbStage11 = new JLabel();
    private JLabel jlbStage12 = new JLabel();
    private JLabel jlbStage13 = new JLabel();
    private JLabel jlbStage14= new JLabel();
    private JLabel jlbStage15 = new JLabel();
    private JLabel jlbStageBoss= new JLabel();
    private ImageIcon iconEnemy = new ImageIcon("img/enemy.png");
    private ImageIcon iconEnemyB = new ImageIcon("img/enemyB.png");
    private ImageIcon iconEnemyC = new ImageIcon("img/enemyC.png");

    private ImageIcon iconShop = new ImageIcon("img/shop.png");
    private ImageIcon iconShopB = new ImageIcon("img/shopB.png");
    private ImageIcon iconShopC = new ImageIcon("img/shopC.png");

    private ImageIcon iconsEnemy = new ImageIcon("img/sEnemy.png");
    private ImageIcon iconsEnemyB = new ImageIcon("img/sEnemyB.png");
    private ImageIcon iconsEnemyC = new ImageIcon("img/sEnemyC.png");

    private ImageIcon iconBox = new ImageIcon("img/box.png");
    private ImageIcon iconBoxB = new ImageIcon("img/boxB.png");
    private ImageIcon iconBoxC = new ImageIcon("img/boxC.png");

    private ImageIcon iconRest = new ImageIcon("img/rest.png");
    private ImageIcon iconRestB = new ImageIcon("img/restB.png");
    private ImageIcon iconRestC = new ImageIcon("img/restC.png");

    private ImageIcon iconQuest = new ImageIcon("img/quest.png");
    private ImageIcon iconQuestB = new ImageIcon("img/questB.png");
    private ImageIcon iconQuestC = new ImageIcon("img/questC.png");

    private ImageIcon iconBoss = new ImageIcon("img/boss.png");
    private ImageIcon iconBossR = new ImageIcon("img/bossR.png");
    private int pass1 = Map.pass1;

    public Map2(){
        init();
    }
    public void init(){
        this.setBounds(150,100,1600,850);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setDefaultLookAndFeelDecorated(true);
        this.setResizable(false);
        cp =this.getContentPane();
        cp.setLayout(null);
        cp.setBackground(new Color(141,141,130));
        cp.add(jlbStage1);
        cp.add(jlbStage2);
        cp.add(jlbStage3);
        cp.add(jlbStage4);
        cp.add(jlbStage5);
        cp.add(jlbStage6);
        cp.add(jlbStage7);
        cp.add(jlbStage8);
        cp.add(jlbStage9);
        cp.add(jlbStage10);
        cp.add(jlbStage11);
        cp.add(jlbStage12);
        cp.add(jlbStage13);
        cp.add(jlbStage14);
        cp.add(jlbStage15);
        cp.add(jlbStageBoss);
        cp.add(jbtClose);

        jlbStage1.setBounds(50,250,26,26);
        jlbStage2.setBounds(150,250,26,26);
        jlbStage3.setBounds(247,248,32,30);
        jlbStage4.setBounds(350,245,27,36);
        jlbStage5.setBounds(443,246,40,33);
        jlbStage6.setBounds(547,246,33,34);
        jlbStage7.setBounds(650,245,27,36);
        jlbStage8.setBounds(750,250,26,26);
        jlbStage9.setBounds(844,250,38,27);
        jlbStage10.setBounds(943,246,40,33);
        jlbStage11.setBounds(1047,248,32,30);
        jlbStage12.setBounds(1150,245,27,36);
        jlbStage13.setBounds(1247,246,33,34);
        jlbStage14.setBounds(1350,250,26,26);
        jlbStage15.setBounds(1447,246,33,34);
        jlbStageBoss.setBounds(700,500,188,200);
        jbtClose.setBounds(1300, 500,100,50);

        //        敵人圖片
        Image imgEnemy = iconEnemy.getImage();
        Image newImgEnemy = imgEnemy.getScaledInstance(26,26, Image.SCALE_SMOOTH);
        iconEnemy = new ImageIcon(newImgEnemy);

        Image imgEnemyB = iconEnemyB.getImage();
        Image newImgEnemyB = imgEnemyB.getScaledInstance(63,63, Image.SCALE_SMOOTH);
        iconEnemyB = new ImageIcon(newImgEnemyB);

        Image imgEnemyC = iconEnemyC.getImage();
        Image newImgEnemyC = imgEnemyC.getScaledInstance(76,79, Image.SCALE_SMOOTH);
        iconEnemyC = new ImageIcon(newImgEnemyC);

//        商人圖片
        Image imgShop = iconShop.getImage();
        Image newImgShop = imgShop.getScaledInstance(32,36, Image.SCALE_SMOOTH);
        iconShop = new ImageIcon(newImgShop);

        Image imgShopB = iconShopB.getImage();
        Image newImgShopB = imgShopB.getScaledInstance(74,70, Image.SCALE_SMOOTH);
        iconShopB = new ImageIcon(newImgShopB);

        Image imgShopC = iconShopC.getImage();
        Image newImgShopC = imgShopC.getScaledInstance(80,77, Image.SCALE_SMOOTH);
        iconShopC = new ImageIcon(newImgShopC);

//        菁英圖片
        Image imgsEnemy = iconsEnemy.getImage();
        Image newImgsEnemy = imgsEnemy.getScaledInstance(40,33, Image.SCALE_SMOOTH);
        iconsEnemy = new ImageIcon(newImgsEnemy);

        Image imgsEnemyB = iconsEnemyB.getImage();
        Image newImgsEnemyB = imgsEnemyB.getScaledInstance(76,59, Image.SCALE_SMOOTH);
        iconsEnemyB = new ImageIcon(newImgsEnemyB);

        Image imgsEnemyC = iconsEnemyC.getImage();
        Image newImgsEnemyC = imgsEnemyC.getScaledInstance(76,79, Image.SCALE_SMOOTH);
        iconsEnemyC = new ImageIcon(newImgsEnemyC);

//        寶相圖片
        Image imgBox = iconBox.getImage();
        Image newImgBox = imgBox.getScaledInstance(38,27, Image.SCALE_SMOOTH);
        iconBox = new ImageIcon(newImgBox);

        Image imgBoxB = iconBoxB.getImage();
        Image newImgBoxB = imgBoxB.getScaledInstance(95,68, Image.SCALE_SMOOTH);
        iconBoxB = new ImageIcon(newImgBoxB);

        Image imgBoxC = iconBoxC.getImage();
        Image newImgBoxC = imgBoxC.getScaledInstance(75,79, Image.SCALE_SMOOTH);
        iconBoxC = new ImageIcon(newImgBoxC);

//        休息圖片
        Image imgRest = iconRest.getImage();
        Image newImgRest = imgRest.getScaledInstance(33,34, Image.SCALE_SMOOTH);
        iconRest = new ImageIcon(newImgRest);

        Image imgRestB = iconRestB.getImage();
        Image newImgRestB = imgRestB.getScaledInstance(77,81, Image.SCALE_SMOOTH);
        iconRestB = new ImageIcon(newImgRestB);

        Image imgRestC = iconRestC.getImage();
        Image newImgRestC = imgRestC.getScaledInstance(80,79, Image.SCALE_SMOOTH);
        iconRestC = new ImageIcon(newImgRestC);

//        問號圖片
        Image imgQuest = iconQuest.getImage();
        Image newImgQuest = imgQuest.getScaledInstance(27,36, Image.SCALE_SMOOTH);
        iconQuest = new ImageIcon(newImgQuest);

        Image imgQuestB = iconQuestB.getImage();
        Image newImgQuestB = imgQuestB.getScaledInstance(59,88, Image.SCALE_SMOOTH);
        iconQuestB = new ImageIcon(newImgQuestB);

        Image imgQuestC = iconQuestC.getImage();
        Image newImgQuestC = imgQuestC.getScaledInstance(79,78, Image.SCALE_SMOOTH);
        iconQuestC = new ImageIcon(newImgQuestC);

//        王圖片
        Image imgBoss = iconBoss.getImage();
        Image newImgBoss = imgBoss.getScaledInstance(188,200, Image.SCALE_DEFAULT);
        iconBoss = new ImageIcon(newImgBoss);


        Image imgBossR = iconBossR.getImage();
        Image newImgBossR = imgBossR.getScaledInstance(188,200, Image.SCALE_SMOOTH);
        iconBossR = new ImageIcon(newImgBossR);

//        其他圖片
        jlbStage1.setIcon(iconEnemyB);
        jlbStage2.setIcon(iconEnemy);
        jlbStage3.setIcon(iconShop);
        jlbStage4.setIcon(iconQuest);
        jlbStage5.setIcon(iconsEnemy);
        jlbStage6.setIcon(iconRest);
        jlbStage7.setIcon(iconQuest);
        jlbStage8.setIcon(iconEnemy);
        jlbStage9.setIcon(iconBox);
        jlbStage10.setIcon(iconsEnemy);
        jlbStage11.setIcon(iconShop);
        jlbStage12.setIcon(iconQuest);
        jlbStage13.setIcon(iconRest);
        jlbStage14.setIcon(iconEnemy);
        jlbStage15.setIcon(iconRest);
        jlbStageBoss.setIcon(iconBoss);



        jbtClose.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Map2.this.setVisible(false);
            }
        });



        switch (pass1){
            case 1 :
                jlbStage1.setIcon(iconEnemyC);
                jlbStage1.setBounds(25,224,76,79);
            break;
            case 2 :
                jlbStage1.setIcon(iconEnemyC); jlbStage2.setIcon(iconEnemyC);
                jlbStage1.setBounds(25,224,76,79);jlbStage2.setBounds(125,224,76,79);
            break;
            case 3 :
                jlbStage1.setIcon(iconEnemyC); jlbStage2.setIcon(iconEnemyC); jlbStage3.setIcon(iconShopC);
                jlbStage1.setBounds(25,224,76,79);jlbStage2.setBounds(125,224,76,79);jlbStage3.setBounds(227,225,80,77);
                break;
            case 4 :
                jlbStage1.setIcon(iconEnemyC); jlbStage2.setIcon(iconEnemyC); jlbStage3.setIcon(iconShopC); jlbStage4.setIcon(iconsEnemyC);
                jlbStage1.setBounds(25,224,76,79);jlbStage2.setBounds(125,224,76,79);jlbStage3.setBounds(227,225,80,77);jlbStage4.setBounds(325,224,76,79);
                break;
            case 5 :
                jlbStage1.setIcon(iconEnemyC); jlbStage2.setIcon(iconEnemyC); jlbStage3.setIcon(iconShopC); jlbStage4.setIcon(iconsEnemyC); jlbStage5.setIcon(iconQuestC);
                jlbStage1.setBounds(25,224,76,79);jlbStage2.setBounds(125,224,76,79);jlbStage3.setBounds(227,225,80,77);jlbStage4.setBounds(325,224,76,79);jlbStage5.setBounds(425,224,79,78);
                break;
            case 6 :
                jlbStage1.setIcon(iconEnemyC); jlbStage2.setIcon(iconEnemyC); jlbStage3.setIcon(iconShopC); jlbStage4.setIcon(iconsEnemyC); jlbStage5.setIcon(iconQuestC); jlbStage6.setIcon(iconRestC);
                jlbStage1.setBounds(25,224,76,79);jlbStage2.setBounds(125,224,76,79);jlbStage3.setBounds(227,225,80,77);jlbStage4.setBounds(325,224,76,79);jlbStage5.setBounds(425,224,79,78);jlbStage6.setBounds(523,222,80,79);
                break;
            case 7 :
                jlbStage1.setIcon(iconEnemyC); jlbStage2.setIcon(iconEnemyC); jlbStage3.setIcon(iconShopC); jlbStage4.setIcon(iconsEnemyC); jlbStage5.setIcon(iconQuestC); jlbStage6.setIcon(iconRestC); jlbStage7.setIcon(iconQuestC);
                jlbStage1.setBounds(25,224,76,79);jlbStage2.setBounds(125,224,76,79);jlbStage3.setBounds(227,225,80,77);jlbStage4.setBounds(325,224,76,79);jlbStage5.setBounds(425,224,79,78);jlbStage6.setBounds(523,222,80,79);jlbStage7.setBounds(625,224,79,78);
                break;
            case 8 :
                jlbStage1.setIcon(iconEnemyC); jlbStage2.setIcon(iconEnemyC); jlbStage3.setIcon(iconShopC); jlbStage4.setIcon(iconsEnemyC); jlbStage5.setIcon(iconQuestC); jlbStage6.setIcon(iconRestC); jlbStage7.setIcon(iconQuestC); jlbStage8.setIcon(iconEnemyC);
                jlbStage1.setBounds(25,224,76,79);jlbStage2.setBounds(125,224,76,79);jlbStage3.setBounds(227,225,80,77);jlbStage4.setBounds(325,224,76,79);jlbStage5.setBounds(425,224,79,78);jlbStage6.setBounds(523,222,80,79);jlbStage7.setBounds(625,224,79,78);jlbStage8.setBounds(725,224,76,79);
                break;
            case 9 :
                jlbStage1.setIcon(iconEnemyC); jlbStage2.setIcon(iconEnemyC); jlbStage3.setIcon(iconShopC); jlbStage4.setIcon(iconsEnemyC); jlbStage5.setIcon(iconQuestC); jlbStage6.setIcon(iconRestC); jlbStage7.setIcon(iconQuestC); jlbStage8.setIcon(iconEnemyC); jlbStage9.setIcon(iconBoxC);
                jlbStage1.setBounds(25,224,76,79);jlbStage2.setBounds(125,224,76,79);jlbStage3.setBounds(227,225,80,77);jlbStage4.setBounds(325,224,76,79);jlbStage5.setBounds(425,224,79,78);jlbStage6.setBounds(523,222,80,79);jlbStage7.setBounds(625,224,79,78);jlbStage8.setBounds(725,224,76,79);jlbStage9.setBounds(825,224,75,79);
                break;
            case 10 :
                jlbStage1.setIcon(iconEnemyC); jlbStage2.setIcon(iconEnemyC); jlbStage3.setIcon(iconShopC); jlbStage4.setIcon(iconsEnemyC); jlbStage5.setIcon(iconQuestC); jlbStage6.setIcon(iconRestC); jlbStage7.setIcon(iconQuestC); jlbStage8.setIcon(iconEnemyC); jlbStage9.setIcon(iconBoxC); jlbStage10.setIcon(iconsEnemyC);
                jlbStage1.setBounds(25,224,76,79);jlbStage2.setBounds(125,224,76,79);jlbStage3.setBounds(227,225,80,77);jlbStage4.setBounds(325,224,76,79);jlbStage5.setBounds(425,224,79,78);jlbStage6.setBounds(523,222,80,79);jlbStage7.setBounds(625,224,79,78);jlbStage8.setBounds(725,224,76,79);jlbStage9.setBounds(825,224,75,79);jlbStage10.setBounds(925,224,76,79);
                break;
            case 11 :
                jlbStage1.setIcon(iconEnemyC); jlbStage2.setIcon(iconEnemyC); jlbStage3.setIcon(iconShopC); jlbStage4.setIcon(iconsEnemyC); jlbStage5.setIcon(iconQuestC); jlbStage6.setIcon(iconRestC); jlbStage7.setIcon(iconQuestC); jlbStage8.setIcon(iconEnemyC); jlbStage9.setIcon(iconBoxC); jlbStage10.setIcon(iconsEnemyC); jlbStage11.setIcon(iconShopC);
                jlbStage1.setBounds(25,224,76,79);jlbStage2.setBounds(125,224,76,79);jlbStage3.setBounds(227,225,80,77);jlbStage4.setBounds(325,224,76,79);jlbStage5.setBounds(425,224,79,78);jlbStage6.setBounds(523,222,80,79);jlbStage7.setBounds(625,224,79,78);jlbStage8.setBounds(725,224,76,79);jlbStage9.setBounds(825,224,75,79);jlbStage10.setBounds(925,224,76,79);jlbStage11.setBounds(1023,224,80,77);
                break;
            case 12 :
                jlbStage1.setIcon(iconEnemyC); jlbStage2.setIcon(iconEnemyC); jlbStage3.setIcon(iconShopC); jlbStage4.setIcon(iconsEnemyC); jlbStage5.setIcon(iconQuestC); jlbStage6.setIcon(iconRestC); jlbStage7.setIcon(iconQuestC); jlbStage8.setIcon(iconEnemyC); jlbStage9.setIcon(iconBoxC); jlbStage10.setIcon(iconsEnemyC); jlbStage11.setIcon(iconShopC); jlbStage12.setIcon(iconQuestC);
                jlbStage1.setBounds(25,224,76,79);jlbStage2.setBounds(125,224,76,79);jlbStage3.setBounds(227,225,80,77);jlbStage4.setBounds(325,224,76,79);jlbStage5.setBounds(425,224,79,78);jlbStage6.setBounds(523,222,80,79);jlbStage7.setBounds(625,224,79,78);jlbStage8.setBounds(725,224,76,79);jlbStage9.setBounds(825,224,75,79);jlbStage10.setBounds(925,224,76,79);jlbStage11.setBounds(1023,224,80,77);jlbStage12.setBounds(1125,224,79,78);
                break;
            case 13 :
                jlbStage1.setIcon(iconEnemyC); jlbStage2.setIcon(iconEnemyC); jlbStage3.setIcon(iconShopC); jlbStage4.setIcon(iconsEnemyC); jlbStage5.setIcon(iconQuestC); jlbStage6.setIcon(iconRestC); jlbStage7.setIcon(iconQuestC); jlbStage8.setIcon(iconEnemyC); jlbStage9.setIcon(iconBoxC); jlbStage10.setIcon(iconsEnemyC); jlbStage11.setIcon(iconShopC); jlbStage12.setIcon(iconQuestC); jlbStage13.setIcon(iconRestC);
                jlbStage1.setBounds(25,224,76,79);jlbStage2.setBounds(125,224,76,79);jlbStage3.setBounds(227,225,80,77);jlbStage4.setBounds(325,224,76,79);jlbStage5.setBounds(425,224,79,78);jlbStage6.setBounds(523,222,80,79);jlbStage7.setBounds(625,224,79,78);jlbStage8.setBounds(725,224,76,79);jlbStage9.setBounds(825,224,75,79);jlbStage10.setBounds(925,224,76,79);jlbStage11.setBounds(1023,224,80,77);jlbStage12.setBounds(1125,224,79,78);jlbStage13.setBounds(1227,220,80,79);
                break;
            case 14 :
                jlbStage1.setIcon(iconEnemyC); jlbStage2.setIcon(iconEnemyC); jlbStage3.setIcon(iconShopC); jlbStage4.setIcon(iconsEnemyC); jlbStage5.setIcon(iconQuestC); jlbStage6.setIcon(iconRestC); jlbStage7.setIcon(iconQuestC); jlbStage8.setIcon(iconEnemyC); jlbStage9.setIcon(iconBoxC); jlbStage10.setIcon(iconsEnemyC); jlbStage11.setIcon(iconShopC); jlbStage12.setIcon(iconQuestC); jlbStage13.setIcon(iconRestC); jlbStage14.setIcon(iconEnemyC);
                jlbStage1.setBounds(25,224,76,79);jlbStage2.setBounds(125,224,76,79);jlbStage3.setBounds(227,225,80,77);jlbStage4.setBounds(325,224,76,79);jlbStage5.setBounds(425,224,79,78);jlbStage6.setBounds(523,222,80,79);jlbStage7.setBounds(625,224,79,78);jlbStage8.setBounds(725,224,76,79);jlbStage9.setBounds(825,224,75,79);jlbStage10.setBounds(925,224,76,79);jlbStage11.setBounds(1023,224,80,77);jlbStage12.setBounds(1125,224,79,78);jlbStage13.setBounds(1227,220,80,79);jlbStage14.setBounds(1325,224,76,79);
                break;
            case 15 :
                jlbStage1.setIcon(iconEnemyC); jlbStage2.setIcon(iconEnemyC); jlbStage3.setIcon(iconShopC); jlbStage4.setIcon(iconsEnemyC); jlbStage5.setIcon(iconQuestC); jlbStage6.setIcon(iconRestC); jlbStage7.setIcon(iconQuestC); jlbStage8.setIcon(iconEnemyC); jlbStage9.setIcon(iconBoxC); jlbStage10.setIcon(iconsEnemyC); jlbStage11.setIcon(iconShopC); jlbStage12.setIcon(iconQuestC); jlbStage13.setIcon(iconRestC); jlbStage14.setIcon(iconEnemyC); jlbStage15.setIcon(iconRestC);
                jlbStage1.setBounds(25,224,76,79);jlbStage2.setBounds(125,224,76,79);jlbStage3.setBounds(227,225,80,77);jlbStage4.setBounds(325,224,76,79);jlbStage5.setBounds(425,224,79,78);jlbStage6.setBounds(523,222,80,79);jlbStage7.setBounds(625,224,79,78);jlbStage8.setBounds(725,224,76,79);jlbStage9.setBounds(825,224,75,79);jlbStage10.setBounds(925,224,76,79);jlbStage11.setBounds(1023,224,80,77);jlbStage12.setBounds(1125,224,79,78);jlbStage13.setBounds(1227,220,80,79);jlbStage14.setBounds(1325,224,76,79);jlbStage15.setBounds(1423,224,80,79);
                break;
            case 16 :
                jlbStage1.setIcon(iconEnemyC); jlbStage2.setIcon(iconEnemyC); jlbStage3.setIcon(iconShopC); jlbStage4.setIcon(iconsEnemyC); jlbStage5.setIcon(iconQuestC); jlbStage6.setIcon(iconRestC); jlbStage7.setIcon(iconQuestC); jlbStage8.setIcon(iconEnemyC); jlbStage9.setIcon(iconBoxC); jlbStage10.setIcon(iconsEnemyC); jlbStage11.setIcon(iconShopC); jlbStage12.setIcon(iconQuestC); jlbStage13.setIcon(iconRestC); jlbStage14.setIcon(iconEnemyC); jlbStage15.setIcon(iconRestC); jlbStageBoss.setIcon(iconBossR);
                jlbStage1.setBounds(25,224,76,79);jlbStage2.setBounds(125,224,76,79);jlbStage3.setBounds(227,225,80,77);jlbStage4.setBounds(325,224,76,79);jlbStage5.setBounds(425,224,79,78);jlbStage6.setBounds(523,222,80,79);jlbStage7.setBounds(625,224,79,78);jlbStage8.setBounds(725,224,76,79);jlbStage9.setBounds(825,224,75,79);jlbStage10.setBounds(925,224,76,79);jlbStage11.setBounds(1023,224,80,77);jlbStage12.setBounds(1125,224,79,78);jlbStage13.setBounds(1227,220,80,79);jlbStage14.setBounds(1325,224,76,79);jlbStage15.setBounds(1423,224,80,79);
                break;
        }

    }
}
